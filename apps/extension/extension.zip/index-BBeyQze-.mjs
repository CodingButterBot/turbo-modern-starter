import { l as p, a as E, n as A, p as S, r as f, j as K } from "./vendor-DASaGGaw.mjs";
class M {
  constructor(e = chrome.storage.local) {
    this.storageProvider = e;
  }
  /**
   * Retrieve a value from storage by key
   * 
   * @param key - Storage key to retrieve
   * @returns Promise resolving to the value or undefined
   */
  async get(e) {
    return new Promise((t) => {
      this.storageProvider.get(e, (r) => {
        chrome.runtime.lastError ? (console.error("Storage get error:", chrome.runtime.lastError), t(void 0)) : t(r[e]);
      });
    });
  }
  /**
   * Store a value in storage
   * 
   * @param key - Storage key
   * @param value - Value to store
   * @returns Promise that resolves when the operation completes
   */
  async set(e, t) {
    return new Promise((r, s) => {
      this.storageProvider.set({ [e]: t }, () => {
        chrome.runtime.lastError ? (console.error("Storage set error:", chrome.runtime.lastError), s(chrome.runtime.lastError)) : r();
      });
    });
  }
  /**
   * Delete a value from storage
   * 
   * @param key - Storage key to delete
   * @returns Promise that resolves when the operation completes
   */
  async delete(e) {
    return new Promise((t, r) => {
      this.storageProvider.remove(e, () => {
        chrome.runtime.lastError ? (console.error("Storage delete error:", chrome.runtime.lastError), r(chrome.runtime.lastError)) : t();
      });
    });
  }
}
new M();
const h = {
  URL: "directus_url",
  ACCESS_TOKEN: "directusAccessToken",
  // Using existing key from the old implementation
  REFRESH_TOKEN: "directusRefreshToken",
  // Using existing key from the old implementation
  EXPIRATION: "directusTokenExpiration",
  // Using existing key from the old implementation
  AUTH_STATE: "directus_auth_state"
};
class j {
  /**
   * Create a new DirectusSdkClient instance
   * 
   * @param defaultUrl - Default Directus API URL
   */
  constructor(e = "http://localhost:8055") {
    this.url = e, this.storageAdapter = new M(), this.client = p(e).with(E()).with(A("json", {
      autoRefresh: !0
    })), this.init();
  }
  /**
   * Initialize the Directus client
   * Restores URL and auth state from storage
   */
  async init() {
    try {
      const e = await this.storageAdapter.get(h.URL);
      e && (this.url = e, this.client = p(e).with(E()).with(A("json", {
        autoRefresh: !0
      })));
      const t = await this.storageAdapter.get(h.ACCESS_TOKEN), r = await this.storageAdapter.get(h.REFRESH_TOKEN), s = await this.storageAdapter.get(h.EXPIRATION);
      if (t && r && s)
        if (s > Date.now())
          this.client = this.client.with(S(t)), await this.updateAuthState(!0);
        else {
          const o = await this.refreshToken(r);
          await this.updateAuthState(o);
        }
      else
        await this.updateAuthState(!1);
    } catch (e) {
      console.error("Error initializing Directus client:", e), await this.updateAuthState(!1);
    }
  }
  /**
   * Update authentication state in storage
   * 
   * @param isAuthenticated - Authentication state
   */
  async updateAuthState(e) {
    try {
      await this.storageAdapter.set(h.AUTH_STATE, {
        isAuthenticated: e,
        lastChecked: Date.now()
      });
    } catch (t) {
      console.error("Error updating auth state:", t);
    }
  }
  /**
   * Set Directus API URL
   * 
   * @param url - Directus API URL
   */
  async setUrl(e) {
    this.url = e, await this.storageAdapter.set(h.URL, e), this.client = p(e).with(E()).with(A("json", {
      autoRefresh: !0
    }));
    const t = await this.storageAdapter.get(h.ACCESS_TOKEN);
    t && (this.client = this.client.with(S(t)));
  }
  /**
   * Get current Directus URL
   * 
   * @returns Current API URL
   */
  async getUrl() {
    return await this.storageAdapter.get(h.URL) || this.url;
  }
  /**
   * Authenticate with Directus
   * 
   * @param email - User email
   * @param password - User password
   * @returns Authentication result
   */
  async login(e, t) {
    try {
      console.log("Attempting login with Directus:", { email: e });
      const r = await this.client.login(e, t);
      return console.log("Login successful, storing tokens"), await this.storageAdapter.set(h.ACCESS_TOKEN, r.access_token), await this.storageAdapter.set(h.REFRESH_TOKEN, r.refresh_token), await this.storageAdapter.set(h.EXPIRATION, Date.now() + r.expires * 1e3), this.client = this.client.with(S(r.access_token)), await this.updateAuthState(!0), r;
    } catch (r) {
      throw console.error("Login error:", r), await this.updateAuthState(!1), r;
    }
  }
  /**
   * Refresh authentication token
   * 
   * @param refreshToken - Optional refresh token (retrieved from storage if not provided)
   * @returns True if refresh was successful
   */
  async refreshToken(e) {
    try {
      if (console.log("Attempting to refresh token"), e || (e = await this.storageAdapter.get(h.REFRESH_TOKEN)), !e)
        return console.warn("No refresh token available"), await this.updateAuthState(!1), !1;
      const t = await this.client.refresh(e);
      return console.log("Token refresh successful, storing new tokens"), await this.storageAdapter.set(h.ACCESS_TOKEN, t.access_token), await this.storageAdapter.set(h.REFRESH_TOKEN, t.refresh_token), await this.storageAdapter.set(h.EXPIRATION, Date.now() + t.expires * 1e3), this.client = this.client.with(S(t.access_token)), await this.updateAuthState(!0), !0;
    } catch (t) {
      return console.error("Token refresh error:", t), await this.logout(), !1;
    }
  }
  /**
   * Log out from Directus
   * Clears all authentication data
   */
  async logout() {
    try {
      console.log("Logging out from Directus");
      try {
        await this.client.logout();
      } catch (e) {
        console.warn("API logout failed, but continuing with local logout:", e);
      }
      await this.storageAdapter.delete(h.ACCESS_TOKEN), await this.storageAdapter.delete(h.REFRESH_TOKEN), await this.storageAdapter.delete(h.EXPIRATION), this.client = p(this.url).with(E()).with(A("json", {
        autoRefresh: !0
      })), await this.updateAuthState(!1);
    } catch (e) {
      console.error("Logout error:", e), await this.updateAuthState(!1);
    }
  }
  /**
   * Check if user is authenticated
   * 
   * @returns True if authenticated
   */
  async isAuthenticated() {
    try {
      const e = await this.storageAdapter.get(h.ACCESS_TOKEN), t = await this.storageAdapter.get(h.EXPIRATION);
      return !e || !t ? (await this.updateAuthState(!1), !1) : t < Date.now() ? (console.log("Token expired, attempting refresh"), await this.refreshToken()) : (await this.updateAuthState(!0), !0);
    } catch (e) {
      return console.error("Auth check error:", e), await this.updateAuthState(!1), !1;
    }
  }
  /**
   * Get current user info from Directus
   * 
   * @returns Current user information
   */
  async getCurrentUser() {
    try {
      return await this.client.request(
        A.readMe({
          fields: ["*"]
        })
      );
    } catch (e) {
      if (this.isAuthError(e) && await this.refreshToken())
        return await this.client.request(
          A.readMe({
            fields: ["*"]
          })
        );
      throw e;
    }
  }
  /**
   * Get module options from Directus
   * 
   * @returns Module options
   */
  async getModuleOptions() {
    try {
      return await this.client.request(
        E.readItems("module_options", {
          fields: ["*", "items.*"]
        })
      );
    } catch (e) {
      if (this.isAuthError(e) && await this.refreshToken())
        return await this.client.request(
          E.readItems("module_options", {
            fields: ["*", "items.*"]
          })
        );
      throw e;
    }
  }
  /**
   * Get module option items by options ID
   * 
   * @param optionsId - ID of the module options
   * @returns List of module option items
   */
  async getModuleOptionItems(e) {
    try {
      return await this.client.request(
        E.readItems("module_option_items", {
          fields: ["*"],
          filter: {
            options_id: { _eq: e }
          }
        })
      );
    } catch (t) {
      if (this.isAuthError(t) && await this.refreshToken())
        return await this.client.request(
          E.readItems("module_option_items", {
            fields: ["*"],
            filter: {
              options_id: { _eq: e }
            }
          })
        );
      throw t;
    }
  }
  /**
   * Check if error is authentication related
   * 
   * @param error - Error to check
   * @returns True if it's an auth error
   */
  isAuthError(e) {
    var r, s, o;
    const t = (o = (s = (r = e == null ? void 0 : e.errors) == null ? void 0 : r[0]) == null ? void 0 : s.extensions) == null ? void 0 : o.code;
    return t === "UNAUTHORIZED" || t === "INVALID_CREDENTIALS" || t === "TOKEN_EXPIRED";
  }
  /**
   * Get the raw Directus SDK client for direct usage
   * 
   * @returns Raw Directus SDK client
   */
  getClient() {
    return this.client;
  }
  /**
   * Get authentication state from storage
   * 
   * @returns Current authentication state
   */
  async getAuthState() {
    return await this.storageAdapter.get(h.AUTH_STATE) || { isAuthenticated: !1, lastChecked: 0 };
  }
}
const b = new j();
class X {
  constructor() {
    this.listeners = [], this.state = {
      isAuthenticated: !1,
      isLoading: !0,
      error: null
    }, this.initializeState(), chrome.runtime.onMessage.addListener((e) => e.type === "AUTH_STATUS_CHANGED" ? (this.updateState({
      isAuthenticated: e.payload.isAuthenticated,
      isLoading: e.payload.isLoading,
      error: e.payload.error
    }), !0) : !1);
  }
  /**
   * Initialize auth state from storage
   */
  async initializeState() {
    try {
      const { isAuthenticated: e } = await b.getAuthState();
      this.updateState({
        isAuthenticated: e,
        isLoading: !1,
        error: null
      });
    } catch (e) {
      console.error("Error initializing auth state:", e), this.updateState({
        isAuthenticated: !1,
        isLoading: !1,
        error: e instanceof Error ? e.message : "Unknown error"
      });
    }
  }
  /**
   * Update authentication state and notify listeners
   * 
   * @param newState - New auth state or partial state
   */
  updateState(e) {
    this.state = { ...this.state, ...e };
    for (const t of this.listeners)
      t(this.state);
  }
  /**
   * Subscribe to authentication state changes
   * 
   * @param handler - Callback function for state changes
   * @returns Unsubscribe function
   */
  subscribe(e) {
    return this.listeners.push(e), e(this.state), () => {
      this.listeners = this.listeners.filter((t) => t !== e);
    };
  }
  /**
   * Check authentication status
   * 
   * @returns Current authentication state
   */
  async checkAuthStatus() {
    try {
      this.updateState({ isLoading: !0 });
      const e = await b.isAuthenticated();
      return this.updateState({
        isAuthenticated: e,
        isLoading: !1,
        error: null
      }), this.state;
    } catch (e) {
      return console.error("Error checking auth status:", e), this.updateState({
        isAuthenticated: !1,
        isLoading: !1,
        error: e instanceof Error ? e.message : "Error checking authentication status"
      }), this.state;
    }
  }
  /**
   * Login with Directus
   * 
   * @param email - User email
   * @param password - User password
   * @returns Current authentication state after login attempt
   */
  async login(e, t) {
    try {
      return this.updateState({
        isLoading: !0,
        error: null
      }), await b.login(e, t), this.updateState({
        isAuthenticated: !0,
        isLoading: !1,
        error: null
      }), this.broadcastAuthStatusChange(), this.state;
    } catch (r) {
      return console.error("Login error:", r), this.updateState({
        isAuthenticated: !1,
        isLoading: !1,
        error: r instanceof Error ? r.message : "Login failed"
      }), this.state;
    }
  }
  /**
   * Logout from Directus
   * 
   * @returns Current authentication state after logout
   */
  async logout() {
    try {
      return this.updateState({ isLoading: !0 }), await b.logout(), this.updateState({
        isAuthenticated: !1,
        isLoading: !1,
        error: null
      }), this.broadcastAuthStatusChange(), this.state;
    } catch (e) {
      return console.error("Logout error:", e), this.updateState({
        isLoading: !1,
        error: e instanceof Error ? e.message : "Logout failed"
      }), this.state;
    }
  }
  /**
   * Refresh authentication token
   * 
   * @returns Current authentication state after refresh
   */
  async refreshToken() {
    try {
      this.updateState({ isLoading: !0 });
      const e = await b.refreshToken();
      return this.updateState({
        isAuthenticated: e,
        isLoading: !1,
        error: e ? null : "Token refresh failed"
      }), this.broadcastAuthStatusChange(), this.state;
    } catch (e) {
      return console.error("Token refresh error:", e), this.updateState({
        isAuthenticated: !1,
        isLoading: !1,
        error: e instanceof Error ? e.message : "Token refresh failed"
      }), this.state;
    }
  }
  /**
   * Get current authentication state
   * 
   * @returns Current authentication state
   */
  getState() {
    return { ...this.state };
  }
  /**
   * Broadcast authentication state change to all contexts
   */
  broadcastAuthStatusChange() {
    try {
      chrome.runtime.sendMessage({
        type: "AUTH_STATUS_CHANGED",
        payload: this.state
      }).catch((e) => {
        console.log("Auth broadcast error (expected):", e);
      });
    } catch (e) {
      console.log("Auth broadcast runtime error (expected):", e);
    }
  }
}
const R = new X(), x = f.createContext({
  isAuthenticated: !1,
  isLoading: !0,
  checkAuth: async () => !1,
  login: async () => !1,
  logout: async () => {
  },
  error: null
}), ce = () => f.useContext(x), he = ({ children: a }) => {
  const [e, t] = f.useState(!1), [r, s] = f.useState(!0), [o, n] = f.useState(null), g = (c) => {
    t(c.isAuthenticated), s(c.isLoading), n(c.error);
  }, [O, D] = f.useState(0), _ = async () => {
    try {
      const c = Date.now();
      if (c - O < 2e3)
        return console.log("Auth check throttled, skipping to prevent UI flickering"), e;
      D(c), e || s(!0);
      const l = await R.checkAuthStatus();
      if (e && l.isAuthenticated)
        return l.error !== o && n(l.error), s(!1), !0;
      if (g(l), !l.isAuthenticated) {
        const y = localStorage.getItem("lastTokenRefreshAttempt"), U = Date.now();
        if (y && U - parseInt(y, 10) < 3e4)
          return console.log("Token refresh attempted recently, skipping to avoid timeout"), s(!1), !1;
        localStorage.setItem("lastTokenRefreshAttempt", U.toString());
        try {
          console.log("Not authenticated, attempting token refresh");
          const N = await R.refreshToken();
          return g(N), N.isAuthenticated;
        } catch (N) {
          return console.warn("Token refresh failed:", N), s(!1), !1;
        }
      }
      return l.isAuthenticated;
    } catch (c) {
      return console.warn("Error validating authentication:", c), n("Failed to validate authentication status"), t(!1), s(!1), !1;
    }
  }, u = async (c, T) => {
    try {
      const l = await R.login(c, T);
      return g(l), l.isAuthenticated;
    } catch (l) {
      return console.warn("Error during login:", l), n("Failed to log in"), s(!1), !1;
    }
  }, w = async () => {
    try {
      const c = await R.logout();
      g(c);
    } catch (c) {
      console.warn("Error during logout:", c), n("Failed to log out"), s(!1);
    }
  };
  return f.useEffect(() => {
    const c = R.subscribe(g);
    _();
    const T = setInterval(() => {
      _();
    }, 5 * 60 * 1e3);
    return () => {
      c(), clearInterval(T);
    };
  }, []), /* @__PURE__ */ K.jsx(x.Provider, { value: { isAuthenticated: e, isLoading: r, checkAuth: _, login: u, logout: w, error: o }, children: a });
}, i = {
  URL: "directus_url",
  ACCESS_TOKEN: "directusAccessToken",
  REFRESH_TOKEN: "directusRefreshToken",
  EXPIRATION: "directusTokenExpiration",
  AUTH_STATE: "directus_auth_state"
};
class v {
  constructor(e = chrome.storage.local) {
    console.log("ExtensionStorageAdapter constructor called with storage"), this.storage = e;
  }
  async get(e) {
    return new Promise((t) => {
      this.storage.get(e, (r) => {
        chrome.runtime.lastError ? (console.error("Storage get error:", chrome.runtime.lastError), t(void 0)) : t(r[e]);
      });
    });
  }
  async set(e, t) {
    return new Promise((r, s) => {
      this.storage.set({ [e]: t }, () => {
        chrome.runtime.lastError ? (console.error("Storage set error:", chrome.runtime.lastError), s(chrome.runtime.lastError)) : r();
      });
    });
  }
  async remove(e) {
    return new Promise((t, r) => {
      this.storage.remove(e, () => {
        chrome.runtime.lastError ? (console.error("Storage delete error:", chrome.runtime.lastError), r(chrome.runtime.lastError)) : t();
      });
    });
  }
}
class G {
  constructor(e = {}) {
    this.url = e.url || "http://localhost:8055", this.storageAdapter = new v(), this.client = p(this.url).with(E()).with(A("json", {
      autoRefresh: !0
    })), this.init();
  }
  async init() {
    try {
      const e = await this.storageAdapter.get(i.URL);
      e && (this.url = e, this.client = p(e).with(E()).with(A("json", {
        autoRefresh: !0
      })));
      const t = await this.storageAdapter.get(i.ACCESS_TOKEN), r = await this.storageAdapter.get(i.REFRESH_TOKEN), s = await this.storageAdapter.get(i.EXPIRATION);
      if (t && r && s)
        if (s > Date.now())
          this.client = this.client.with(S(t)), await this.updateAuthState(!0);
        else {
          const o = await this.refreshToken();
          await this.updateAuthState(o);
        }
      else
        await this.updateAuthState(!1);
    } catch (e) {
      console.error("Error initializing Directus client:", e), await this.updateAuthState(!1);
    }
  }
  async updateAuthState(e) {
    try {
      await this.storageAdapter.set(i.AUTH_STATE, {
        isAuthenticated: e,
        lastChecked: Date.now()
      });
    } catch (t) {
      console.error("Error updating auth state:", t);
    }
  }
  async getDirectusUrl() {
    return await this.storageAdapter.get(i.URL) || this.url;
  }
  async setDirectusUrl(e) {
    this.url = e, await this.storageAdapter.set(i.URL, e), this.client = p(e).with(E()).with(A("json", {
      autoRefresh: !0
    }));
    const t = await this.storageAdapter.get(i.ACCESS_TOKEN);
    t && (this.client = this.client.with(S(t)));
  }
  async getDirectusToken() {
    return this.storageAdapter.get(i.ACCESS_TOKEN);
  }
  async getDirectusRefreshToken() {
    return this.storageAdapter.get(i.REFRESH_TOKEN);
  }
  async getDirectusTokenExpiration() {
    return this.storageAdapter.get(i.EXPIRATION);
  }
  async setDirectusTokens(e, t, r) {
    await this.storageAdapter.set(i.ACCESS_TOKEN, e), await this.storageAdapter.set(i.REFRESH_TOKEN, t), await this.storageAdapter.set(i.EXPIRATION, Date.now() + r * 1e3), this.client = this.client.with(S(e)), await this.updateAuthState(!0);
  }
  async setDirectusToken(e) {
    await this.storageAdapter.set(i.ACCESS_TOKEN, e), this.client = this.client.with(S(e));
  }
  async validateToken() {
    try {
      const e = await this.storageAdapter.get(i.ACCESS_TOKEN), t = await this.storageAdapter.get(i.EXPIRATION);
      return !e || !t ? (console.log("No token or expiration found"), !1) : t < Date.now() ? (console.log("Token expired, attempting refresh"), await this.refreshToken()) : (console.log("Token valid and not expired"), !0);
    } catch (e) {
      return console.error("Error validating token:", e), !1;
    }
  }
  async clearAuthTokens() {
    try {
      console.log("Clearing auth tokens"), await this.storageAdapter.remove(i.ACCESS_TOKEN), await this.storageAdapter.remove(i.REFRESH_TOKEN), await this.storageAdapter.remove(i.EXPIRATION), await this.updateAuthState(!1), this.client = p(this.url).with(E()).with(A("json", {
        autoRefresh: !0
      }));
    } catch (e) {
      console.error("Error clearing auth tokens:", e);
    }
  }
  async refreshToken() {
    try {
      console.log("Starting token refresh");
      const e = await this.storageAdapter.get(i.REFRESH_TOKEN);
      if (!e)
        return console.log("No refresh token found"), await this.clearAuthTokens(), !1;
      try {
        const t = await this.client.refresh(e);
        return console.log("Token refresh successful, storing new tokens"), await this.storageAdapter.set(i.ACCESS_TOKEN, t.access_token), await this.storageAdapter.set(i.REFRESH_TOKEN, t.refresh_token), await this.storageAdapter.set(i.EXPIRATION, Date.now() + t.expires * 1e3), this.client = this.client.with(S(t.access_token)), await this.updateAuthState(!0), !0;
      } catch (t) {
        return console.error("Token refresh API error:", t), await this.clearAuthTokens(), !1;
      }
    } catch (e) {
      return console.error("Token refresh error:", e), await this.clearAuthTokens(), !1;
    }
  }
  async authenticateWithCredentials({ email: e, password: t }) {
    try {
      console.log("Attempting login with Directus:", { email: e });
      const r = await this.client.login(e, t);
      return console.log("Login successful, storing tokens"), await this.storageAdapter.set(i.ACCESS_TOKEN, r.access_token), await this.storageAdapter.set(i.REFRESH_TOKEN, r.refresh_token), await this.storageAdapter.set(i.EXPIRATION, Date.now() + r.expires * 1e3), this.client = this.client.with(S(r.access_token)), await this.updateAuthState(!0), r;
    } catch (r) {
      throw console.error("Login error:", r), await this.updateAuthState(!1), r;
    }
  }
  async makeAuthenticatedRequest(e, t = {}) {
    try {
      if (!await this.validateToken())
        throw new Error("AUTH_REQUIRED");
      const s = await this.storageAdapter.get(i.ACCESS_TOKEN);
      if (!s)
        throw new Error("AUTH_REQUIRED");
      const o = {
        ...t.headers,
        Authorization: `Bearer ${s}`
      }, n = await fetch(`${this.url}${e}`, {
        ...t,
        headers: o
      });
      if (n.status === 401) {
        if (await this.refreshToken())
          return this.makeAuthenticatedRequest(e, t);
        throw new Error("AUTH_REQUIRED");
      }
      return n;
    } catch (r) {
      throw console.error("Error making authenticated request:", r), r;
    }
  }
  async getModuleOptions() {
    try {
      const e = await this.makeAuthenticatedRequest("/items/module_options");
      if (!e.ok)
        throw new Error(`Failed to fetch module options: ${e.status}`);
      return await e.json();
    } catch (e) {
      throw console.error("Error getting module options:", e), e;
    }
  }
  async getItemsByOptionsId(e) {
    try {
      const t = await this.makeAuthenticatedRequest(
        `/items/module_option_items?filter[options_id][_eq]=${e}`
      );
      if (!t.ok)
        throw new Error(`Failed to fetch option items: ${t.status}`);
      return await t.json();
    } catch (t) {
      throw console.error("Error getting option items:", t), t;
    }
  }
  async getAuthState() {
    try {
      const e = await this.storageAdapter.get(i.AUTH_STATE);
      if (e)
        return e;
      const r = {
        isAuthenticated: await this.validateToken(),
        lastChecked: Date.now()
      };
      return await this.storageAdapter.set(i.AUTH_STATE, r), r;
    } catch (e) {
      return console.error("Error getting auth state:", e), { isAuthenticated: !1, lastChecked: Date.now() };
    }
  }
}
self.DirectusBrowserClient = G;
self.ExtensionStorageAdapter = v;
console.log("DirectusBrowserClient and ExtensionStorageAdapter exposed to service worker global scope");
const I = {
  // Theme settings
  darkMode: !1,
  themePreference: "light",
  // Notification settings
  notifications: !0,
  autoRefresh: !1,
  // Account settings
  isLoggedIn: !1,
  // Authentication tokens
  directusAccessToken: null,
  directusRefreshToken: null,
  directusTokenExpiration: null,
  // Advanced settings
  debugging: !1,
  syncFrequency: !1
};
class B {
  /**
   * Create a new StorageService instance
   * Sets up listeners for storage changes
   */
  constructor() {
    this.memoryStorage = { ...I }, this.listeners = /* @__PURE__ */ new Map(), this.storageArea = "local", typeof chrome < "u" && chrome.storage && chrome.storage.onChanged.addListener((e, t) => {
      t === this.storageArea && this.notifyListeners(e);
    });
  }
  /**
   * Get storage area to use (sync or local)
   * 
   * @private
   * @returns {chrome.storage.LocalStorageArea | chrome.storage.SyncStorageArea | null} The storage area
   */
  getStorageArea() {
    return typeof chrome < "u" && chrome.storage ? this.storageArea === "sync" ? chrome.storage.sync : chrome.storage.local : null;
  }
  /**
   * Notify registered listeners of storage changes
   * 
   * @private
   * @param {Object} changes - Object containing the changes to notify about
   */
  notifyListeners(e) {
    const t = Object.keys(e);
    (this.listeners.get("*") || []).forEach((s) => s(e)), t.forEach((s) => {
      const o = this.listeners.get(s);
      if (o) {
        const n = { [s]: e[s] };
        o.forEach((g) => g(n));
      }
    });
  }
  /**
   * Subscribe to storage changes
   * 
   * @param {string} key - Specific key to listen for or '*' for all changes
   * @param {Function} callback - Function to call when storage changes
   * @returns {Function} Unsubscribe function to remove the listener
   * 
   * @example
   * ```typescript
   * // Subscribe to changes in the 'darkMode' setting
   * const unsubscribe = storageService.subscribe('darkMode', (changes) => {
   *   console.log('Dark mode changed:', changes.darkMode.newValue);
   * });
   * 
   * // Later, when you're done listening:
   * unsubscribe();
   * ```
   */
  subscribe(e, t) {
    this.listeners.has(e) || this.listeners.set(e, []);
    const r = this.listeners.get(e);
    return r && r.push(t), () => {
      const s = this.listeners.get(e) || [], o = s.indexOf(t);
      o !== -1 && s.splice(o, 1);
    };
  }
  /**
   * Get a value or multiple values from storage
   * 
   * @param {T | T[] | Partial<ExtensionSettings> | null} keys - Key(s) to retrieve from storage
   * @returns {Promise<Partial<ExtensionSettings>>} Promise resolving to requested values
   * 
   * @example
   * ```typescript
   * // Get a single value
   * const { darkMode } = await storageService.get('darkMode');
   * 
   * // Get multiple values
   * const { darkMode, notifications } = await storageService.get(['darkMode', 'notifications']);
   * 
   * // Get all settings
   * const allSettings = await storageService.get(null);
   * ```
   */
  async get(e) {
    return new Promise((t) => {
      const r = this.getStorageArea();
      if (r)
        r.get(e, (s) => {
          t(s);
        });
      else if (Array.isArray(e)) {
        const s = {};
        e.forEach((o) => {
          s[o] = this.memoryStorage[o];
        }), t(s);
      } else if (typeof e == "string")
        t({ [e]: this.memoryStorage[e] });
      else if (e && typeof e == "object") {
        const s = {};
        Object.keys(e).forEach((o) => {
          const n = o;
          s[n] = this.memoryStorage[n] ?? e[n];
        }), t(s);
      } else
        t({ ...this.memoryStorage });
    });
  }
  /**
   * Set value(s) in storage
   * 
   * @param {Partial<ExtensionSettings>} items - Key-value pairs to store
   * @returns {Promise<void>} Promise resolving when the operation is complete
   * 
   * @example
   * ```typescript
   * // Set a single value
   * await storageService.set({ darkMode: true });
   * 
   * // Set multiple values
   * await storageService.set({
   *   darkMode: true,
   *   notifications: false
   * });
   * ```
   */
  async set(e) {
    return new Promise((t, r) => {
      const s = this.getStorageArea();
      if (s)
        s.set(e, () => {
          const o = chrome.runtime.lastError;
          o ? (console.warn("Chrome storage error:", o.message), r(o)) : t();
        });
      else {
        Object.assign(this.memoryStorage, e);
        const o = {};
        Object.keys(e).forEach((n) => {
          o[n] = {
            newValue: e[n],
            oldValue: this.memoryStorage[n]
          };
        }), this.notifyListeners(o), t();
      }
    });
  }
  /**
   * Remove item(s) from storage
   * 
   * @param {T | T[]} keys - Key(s) to remove
   * @returns {Promise<void>} Promise resolving when the operation is complete
   * 
   * @example
   * ```typescript
   * // Remove a single key
   * await storageService.remove('directusAccessToken');
   * 
   * // Remove multiple keys
   * await storageService.remove(['directusAccessToken', 'directusRefreshToken']);
   * ```
   */
  async remove(e) {
    return new Promise((t) => {
      const r = this.getStorageArea();
      if (r)
        r.remove(e, () => {
          t();
        });
      else {
        if (Array.isArray(e)) {
          const s = {};
          e.forEach((o) => {
            s[o] = {
              oldValue: this.memoryStorage[o],
              newValue: void 0
            }, delete this.memoryStorage[o];
          }), this.notifyListeners(s);
        } else {
          const s = {
            [e]: {
              oldValue: this.memoryStorage[e],
              newValue: void 0
            }
          };
          delete this.memoryStorage[e], this.notifyListeners(s);
        }
        t();
      }
    });
  }
  /**
   * Clear all storage
   * 
   * @returns {Promise<void>} Promise resolving when the operation is complete
   * 
   * @example
   * ```typescript
   * // Clear all stored settings
   * await storageService.clear();
   * ```
   */
  async clear() {
    return new Promise((e) => {
      const t = this.getStorageArea();
      if (t)
        t.clear(() => {
          e();
        });
      else {
        const r = { ...this.memoryStorage };
        this.memoryStorage = { ...I };
        const s = {};
        Object.keys(r).forEach((o) => {
          s[o] = {
            oldValue: r[o],
            newValue: void 0
          };
        }), this.notifyListeners(s), e();
      }
    });
  }
  /**
   * Reset all settings to defaults
   * 
   * @returns {Promise<void>} Promise resolving when the operation is complete
   * 
   * @example
   * ```typescript
   * // Reset all settings to their default values
   * await storageService.resetToDefaults();
   * ```
   */
  async resetToDefaults() {
    return this.set(I);
  }
  /**
   * Synchronize settings between devices (when using sync storage)
   * This is automatically handled by Chrome when using sync storage,
   * but this method can be used to force a sync or handle custom logic
   * 
   * @example
   * ```typescript
   * // Force synchronization with other devices
   * await storageService.synchronize();
   * ```
   */
  async synchronize() {
    var e;
    if (!(this.storageArea !== "sync" || !((e = chrome == null ? void 0 : chrome.storage) != null && e.sync)))
      try {
        const t = await this.get(null);
        await this.set(t);
      } catch (t) {
        console.error("Failed to synchronize settings:", t);
      }
  }
}
const P = new B(), d = {
  // Auth messages
  AUTH_STATUS_CHECK: "AUTH_STATUS_CHECK",
  AUTH_LOGIN: "AUTH_LOGIN",
  AUTH_LOGOUT: "AUTH_LOGOUT",
  AUTH_REFRESH_TOKEN: "AUTH_REFRESH_TOKEN",
  AUTH_STATUS_CHANGED: "AUTH_STATUS_CHANGED",
  AUTH_DEBUG: "AUTH_DEBUG",
  // Theme messages
  THEME_GET: "THEME_GET",
  THEME_SET: "THEME_SET",
  THEME_TOGGLE: "THEME_TOGGLE",
  THEME_CHANGED: "THEME_CHANGED",
  // General messages
  EXTENSION_STATE_REQUEST: "EXTENSION_STATE_REQUEST",
  EXTENSION_STATE_BROADCAST: "EXTENSION_STATE_BROADCAST",
  // UI messages
  OPEN_SIDEPANEL: "OPEN_SIDEPANEL"
};
class $ {
  constructor() {
    this.authCallbacks = [], this.themeCallbacks = [], this.generalCallbacks = [], this.currentState = {
      auth: {
        isAuthenticated: !1,
        isLoading: !1,
        error: null
      },
      theme: {
        theme: "light",
        themePreference: "system",
        isLoading: !1
      }
    }, this.setupMessageListener(), this.initializeState();
  }
  /**
   * Set up listener for messages from the background script or other contexts
   */
  setupMessageListener() {
    chrome.runtime.onMessage.addListener((e, t, r) => {
      console.log("ExtensionService received message:", e);
      try {
        e.type === d.AUTH_STATUS_CHANGED ? (this.currentState.auth = e.payload, console.log("Received auth status change:", this.currentState.auth), this.notifyAuthSubscribers(), this.notifyGeneralSubscribers(), this.updateStorageAuthState(this.currentState.auth.isAuthenticated), r({ success: !0 })) : e.type === d.THEME_CHANGED ? (this.currentState.theme = e.payload, this.notifyThemeSubscribers(), this.notifyGeneralSubscribers(), r({ success: !0 })) : e.type === d.EXTENSION_STATE_BROADCAST ? (this.currentState = e.payload, console.log("Received state broadcast:", this.currentState), this.notifyAllSubscribers(), this.updateStorageAuthState(this.currentState.auth.isAuthenticated), r({ success: !0 })) : r({ success: !0, message: "message received" });
      } catch (s) {
        console.error("Error processing message:", s), r({ success: !1, error: s instanceof Error ? s.message : "Unknown error" });
      }
      return !0;
    });
  }
  /**
   * Update storage auth state to ensure consistency
   * @param isAuthenticated Auth state
   */
  async updateStorageAuthState(e) {
    var t;
    try {
      const r = (t = chrome.storage) == null ? void 0 : t.local;
      r && await new Promise((s) => {
        r.set({
          isAuthenticated: e,
          isLoggedIn: e
        }, () => s());
      });
    } catch (r) {
      console.warn("Error updating storage auth state:", r);
    }
  }
  /**
   * Initialize state from storage
   */
  async initializeState() {
    try {
      const e = await this.sendMessage({
        type: d.EXTENSION_STATE_REQUEST
      });
      if (e) {
        this.currentState = e, this.notifyAllSubscribers();
        return;
      }
      const t = await P.get([
        "isAuthenticated",
        "directusAccessToken",
        "directusRefreshToken",
        "directusTokenExpiration"
      ]), r = await P.get([
        "themePreference",
        "darkMode"
      ]);
      this.currentState.auth.isAuthenticated = !!t.isAuthenticated, r.themePreference && (this.currentState.theme.themePreference = r.themePreference, this.currentState.theme.theme = r.darkMode ? "dark" : "light"), this.notifyAllSubscribers();
    } catch (e) {
      console.error("Error initializing extension state:", e);
    }
  }
  /**
   * Send a message to the background script
   */
  async sendMessage(e) {
    return new Promise((t) => {
      console.log(`[${(/* @__PURE__ */ new Date()).toISOString()}] Sending message to background script:`, e);
      const r = e.type === d.AUTH_REFRESH_TOKEN ? 15e3 : 8e3, s = setTimeout(() => {
        console.warn(`[${(/* @__PURE__ */ new Date()).toISOString()}] Message response timeout exceeded for:`, e.type, `(after ${r}ms)`), t({
          isAuthenticated: !1,
          isLoading: !1,
          error: "Message response timeout"
        });
      }, r);
      try {
        chrome.runtime.sendMessage(e, (o) => {
          console.log(`[${(/* @__PURE__ */ new Date()).toISOString()}] Received response for ${e.type}:`, o), clearTimeout(s), chrome.runtime.lastError ? (console.warn(`[${(/* @__PURE__ */ new Date()).toISOString()}] Error sending message:`, chrome.runtime.lastError), t({
            isAuthenticated: !1,
            isLoading: !1,
            error: chrome.runtime.lastError.message
          })) : t(o);
        });
      } catch (o) {
        clearTimeout(s), console.error(`[${(/* @__PURE__ */ new Date()).toISOString()}] Failed to send message:`, o), t({
          isAuthenticated: !1,
          isLoading: !1,
          error: o instanceof Error ? o.message : "Unknown error"
        });
      }
    });
  }
  /**
   * Notify all subscribers of state changes
   */
  notifyAllSubscribers() {
    this.notifyAuthSubscribers(), this.notifyThemeSubscribers(), this.notifyGeneralSubscribers();
  }
  /**
   * Notify auth subscribers of state changes
   */
  notifyAuthSubscribers() {
    for (const e of this.authCallbacks)
      e(this.currentState.auth);
  }
  /**
   * Notify theme subscribers of state changes
   */
  notifyThemeSubscribers() {
    for (const e of this.themeCallbacks)
      e(this.currentState.theme);
  }
  /**
   * Notify general subscribers of state changes
   */
  notifyGeneralSubscribers() {
    for (const e of this.generalCallbacks)
      e(this.currentState);
  }
  /**
   * Check authentication status
   */
  async checkAuthStatus() {
    try {
      const e = await this.sendMessage({ type: d.AUTH_STATUS_CHECK });
      return e && (this.currentState.auth = e, this.notifyAuthSubscribers(), this.notifyGeneralSubscribers()), this.currentState.auth;
    } catch (e) {
      return console.error("Error checking auth status:", e), this.currentState.auth;
    }
  }
  /**
   * Get detailed auth debug information
   * @returns {Promise<object>} Detailed authentication debug information
   */
  async getAuthDebugInfo() {
    try {
      return await this.sendMessage({ type: d.AUTH_DEBUG }) || { error: "No response from background script" };
    } catch (e) {
      return console.error("Error getting auth debug info:", e), {
        error: e instanceof Error ? e.message : "Unknown error",
        stack: e instanceof Error ? e.stack : null
      };
    }
  }
  /**
   * Log in with credentials
   */
  async login(e, t) {
    try {
      const r = await this.sendMessage({
        type: d.AUTH_LOGIN,
        payload: { email: e, password: t }
      });
      return r && (this.currentState.auth = r, this.notifyAuthSubscribers(), this.notifyGeneralSubscribers()), this.currentState.auth;
    } catch (r) {
      return console.error("Login error:", r), this.currentState.auth.error = "Login failed", this.notifyAuthSubscribers(), this.currentState.auth;
    }
  }
  /**
   * Log out
   */
  async logout() {
    try {
      const e = await this.sendMessage({ type: d.AUTH_LOGOUT });
      return e && (this.currentState.auth = e, this.notifyAuthSubscribers(), this.notifyGeneralSubscribers()), this.currentState.auth;
    } catch (e) {
      return console.error("Logout error:", e), this.currentState.auth;
    }
  }
  /**
   * Refresh the auth token
   */
  async refreshToken() {
    try {
      const e = await this.sendMessage({ type: d.AUTH_REFRESH_TOKEN });
      return e && (this.currentState.auth = e, this.notifyAuthSubscribers(), this.notifyGeneralSubscribers()), this.currentState.auth;
    } catch (e) {
      return console.error("Token refresh error:", e), this.currentState.auth;
    }
  }
  /**
   * Get current theme settings
   */
  async getTheme() {
    try {
      const e = await this.sendMessage({ type: d.THEME_GET });
      return e && (this.currentState.theme = e, this.notifyThemeSubscribers(), this.notifyGeneralSubscribers()), this.currentState.theme;
    } catch (e) {
      return console.error("Error getting theme:", e), this.currentState.theme;
    }
  }
  /**
   * Set specific theme
   */
  async setTheme(e) {
    try {
      const t = await this.sendMessage({
        type: d.THEME_SET,
        payload: { themePreference: e }
      });
      return t && (this.currentState.theme = t, this.notifyThemeSubscribers(), this.notifyGeneralSubscribers()), this.currentState.theme;
    } catch (t) {
      return console.error("Error setting theme:", t), this.currentState.theme;
    }
  }
  /**
   * Toggle theme (cycling through light, dark, system)
   */
  async toggleTheme() {
    try {
      const e = await this.sendMessage({
        type: d.THEME_TOGGLE
      });
      return e && (this.currentState.theme = e, this.notifyThemeSubscribers(), this.notifyGeneralSubscribers()), this.currentState.theme;
    } catch (e) {
      return console.error("Error toggling theme:", e), this.currentState.theme;
    }
  }
  /**
   * Subscribe to auth state changes
   */
  subscribeToAuth(e) {
    return this.authCallbacks.push(e), e(this.currentState.auth), () => {
      this.authCallbacks = this.authCallbacks.filter((t) => t !== e);
    };
  }
  /**
   * Subscribe to theme state changes
   */
  subscribeToTheme(e) {
    return this.themeCallbacks.push(e), e(this.currentState.theme), () => {
      this.themeCallbacks = this.themeCallbacks.filter((t) => t !== e);
    };
  }
  /**
   * Subscribe to all extension state changes
   */
  subscribe(e) {
    return this.generalCallbacks.push(e), e(this.currentState), () => {
      this.generalCallbacks = this.generalCallbacks.filter((t) => t !== e);
    };
  }
  /**
   * Get current auth state
   */
  getAuthState() {
    return { ...this.currentState.auth };
  }
  /**
   * Get current theme state
   */
  getThemeState() {
    return { ...this.currentState.theme };
  }
  /**
   * Get entire extension state
   */
  getState() {
    return {
      auth: { ...this.currentState.auth },
      theme: { ...this.currentState.theme }
    };
  }
  /**
   * Open the side panel
   * 
   * NOTE: This method is maintained for backward compatibility, but should NOT be used directly.
   * Due to Chrome's security policy, chrome.sidePanel.open() MUST be called directly in response 
   * to a user gesture (click) and cannot be triggered through messaging.
   * 
   * @deprecated Use chrome.sidePanel.open() directly in response to user clicks
   */
  async openSidePanel() {
    var e, t;
    console.warn(
      "WARNING: Using extensionService.openSidePanel() is deprecated. Call chrome.sidePanel.open() directly in response to user clicks due to Chrome security policies."
    );
    try {
      if ((e = chrome == null ? void 0 : chrome.sidePanel) != null && e.open)
        try {
          return chrome.sidePanel.open({}), { success: !0 };
        } catch (s) {
          if (console.error("Direct sidePanel.open() failed:", s), (t = chrome == null ? void 0 : chrome.tabs) != null && t.query)
            try {
              return chrome.tabs.query({ active: !0, currentWindow: !0 }, (o) => {
                if (o && o.length > 0 && o[0].id)
                  try {
                    chrome.sidePanel.open({ tabId: o[0].id });
                  } catch (n) {
                    console.error("Tab-specific sidePanel.open() failed:", n);
                  }
              }), { success: !0 };
            } catch (o) {
              console.error("Error querying tabs:", o);
            }
        }
      const r = await this.sendMessage({
        type: d.OPEN_SIDEPANEL
      });
      return r && typeof r == "object" ? {
        success: "success" in r ? !!r.success : !1,
        error: "error" in r ? String(r.error || "") : "No detailed error"
      } : { success: !1, error: "No response from background script" };
    } catch (r) {
      return console.error("Error opening side panel:", r), {
        success: !1,
        error: r instanceof Error ? r.message : "Unknown error"
      };
    }
  }
}
const k = new $(), Q = "directusUrl", z = "directusAccessToken", V = "directusRefreshToken", Y = "directusTokenExpiration", W = "directusToken", Z = "http://localhost:8055";
let L = null;
function m() {
  if (!L) {
    const a = new v(P);
    L = new G({
      url: Z,
      storageProvider: a,
      storage: {
        urlKey: Q,
        tokenKey: z,
        refreshTokenKey: V,
        expirationKey: Y,
        legacyTokenKey: W
      }
    });
  }
  return L;
}
async function F() {
  return m().getDirectusToken();
}
async function J() {
  return m().getDirectusTokenExpiration();
}
async function ee() {
  return m().validateToken();
}
async function te() {
  return m().clearAuthTokens();
}
async function ue(a = {}) {
  try {
    const e = await F();
    console.log("Checking for module options authentication:", {
      hasExplicitToken: !!e
    });
    const t = {};
    a.filter && (t.filter = a.filter), a.sort && (t.sort = [a.sort]), a.limit && (t.limit = a.limit);
    const r = m(), s = await r.validateToken();
    if (console.log("Module options auth check result:", { hasToken: s }), s)
      try {
        console.log("Making authenticated module options request...");
        const o = await r.getModuleOptions(t);
        return console.log("Received authenticated module options response"), o.data;
      } catch (o) {
        if (console.error("Error in authenticated module options request:", o), o.message === "AUTH_REQUIRED")
          return await r.clearAuthTokens(), console.log("Authentication required. Using sample data."), H();
        throw o;
      }
    else
      return console.log("No authentication available. Using sample data."), H();
  } catch (e) {
    if (console.warn("Error getting module options:", e), !await m().validateToken())
      return console.log("Error occurred but no authentication available. Falling back to sample data."), H();
    throw e;
  }
}
function H() {
  return [{
    id: "1",
    name: "Demo Options (Not Authenticated)",
    status: "published",
    description: "This is demo data because you are not authenticated with Directus",
    items: []
    // Initialize with empty array to satisfy the interface
  }];
}
async function le(a) {
  try {
    const e = m(), t = await e.validateToken();
    if (a === 1 && !t)
      return console.log("Using demo items for unauthenticated user"), C();
    const r = {
      filter: { options_id: { _eq: a } }
    };
    if (t)
      try {
        return (await e.getItemsByOptionsId(a)).data;
      } catch (s) {
        if (s.message === "AUTH_REQUIRED") {
          if (await e.clearAuthTokens(), a === 1)
            return console.log("Authentication failed. Using demo items."), C();
          throw new Error("Authentication required to view items. Please log in.");
        }
        throw s;
      }
    else {
      if (a === 1)
        return C();
      throw console.log("No authentication available. Cannot fetch real items."), new Error("Authentication required to view items. Please log in.");
    }
  } catch (e) {
    if (console.warn("Error getting module option items:", e), e.message === "AUTH_REQUIRED" || e.message === "Authentication required to view items. Please log in.") {
      if (a === 1)
        return console.log("Using demo items despite authentication error"), C();
      throw e;
    }
    if (a === 1 && !await m().validateToken())
      return console.log("Error occurred but using demo data for the demo option."), C();
    throw e;
  }
}
function C() {
  return [
    { id: "101", options_id: "1", label: "Red Option", color: "#ff0000", weight: 1, status: "published" },
    { id: "102", options_id: "1", label: "Green Option", color: "#00ff00", weight: 1, status: "published" },
    { id: "103", options_id: "1", label: "Blue Option", color: "#0000ff", weight: 1, status: "published" },
    { id: "104", options_id: "1", label: "Yellow Option", color: "#ffff00", weight: 1, status: "published" }
  ];
}
async function re(a) {
  try {
    const e = m();
    if (!await e.validateToken())
      throw new Error("AUTH_REQUIRED");
    const r = {
      options_id: Number(a.options_id),
      result_item_id: Number(a.result_item_id),
      device_info: a.device_info
    };
    return (await e.recordModuleResult(r)).data;
  } catch (e) {
    throw e.message === "AUTH_REQUIRED" ? (console.warn("Authentication required to record results. Please log in again."), new Error("Authentication required to record results. Please log in again.")) : (console.warn("Error recording module result:", e), e);
  }
}
async function de(a, e) {
  if (!a || !a.length)
    throw new Error("No items available to spin");
  const t = a.reduce((o, n) => o + (n.weight || 1), 0);
  let r = Math.random() * t, s = null;
  for (const o of a)
    if (r -= o.weight || 1, r <= 0) {
      s = o;
      break;
    }
  s || (s = a[Math.floor(Math.random() * a.length)]);
  try {
    await m().validateToken() ? await re({
      options_id: Number(e),
      result_item_id: Number(s.id),
      device_info: { platform: "extension" }
    }) : console.log("Demo mode: Result would be recorded if authenticated.");
  } catch (o) {
    o.message.includes("Authentication required") ? (await te(), console.warn("Authentication required to record results. Token cleared.")) : console.warn("Failed to record result, but spin succeeded:", o);
  }
  return s;
}
async function se() {
  try {
    const a = await F(), e = !!a, t = await J(), r = t ? new Date(t) : null, s = t ? t < Date.now() : null, o = await ee(), n = {
      hasToken: e,
      tokenPreview: a ? `${a.substring(0, 10)}...` : null,
      expirationDate: r == null ? void 0 : r.toISOString(),
      currentTime: (/* @__PURE__ */ new Date()).toISOString(),
      isExpired: s,
      isValid: o,
      tokenValid: o ? "Token appears valid" : "Token validation failed"
    };
    return console.log("Authentication state:", n), n;
  } catch (a) {
    return console.error("Error checking auth state:", a), {
      error: a instanceof Error ? a.message : "Unknown error",
      stack: a instanceof Error ? a.stack : null
    };
  }
}
async function ge() {
  console.log("==== AUTH DEBUG START ====");
  try {
    const a = await se();
    console.log("Auth Debug - Component Mount State:", a);
    try {
      const e = await k.getAuthDebugInfo();
      console.log("Auth Debug - Background Script Debug Data:", e);
    } catch (e) {
      console.warn("Auth Debug - Failed to get background script data:", e);
    }
  } catch (a) {
    console.error("Auth Debug - Error during check:", a);
  }
  console.log("==== AUTH DEBUG END ====");
}
var oe = /* @__PURE__ */ ((a) => (a.LIGHT = "light", a.DARK = "dark", a.SYSTEM = "system", a))(oe || {});
const q = f.createContext({
  theme: "light",
  themePreference: "system",
  toggleTheme: () => {
  },
  setTheme: () => {
  },
  isLoading: !0
}), fe = () => f.useContext(q), ae = () => typeof window < "u" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light", Ee = ({ children: a }) => {
  const [e, t] = f.useState(
    "light"
    /* LIGHT */
  ), [r, s] = f.useState(
    "system"
    /* SYSTEM */
  ), [o, n] = f.useState(!0), g = (u) => {
    console.log("Applying theme:", u), u === "dark" ? document.documentElement.classList.add("dark") : document.documentElement.classList.remove("dark"), document.documentElement.setAttribute("data-theme", u), t(u);
  }, O = (u) => {
    const w = u.theme, c = u.themePreference;
    s(c), g(w), n(u.isLoading);
  }, D = async () => {
    try {
      await k.toggleTheme();
    } catch (u) {
      console.error("Error toggling theme:", u);
    }
  }, _ = async (u) => {
    if (console.log("setSpecificTheme called with:", u), u === r) {
      console.log("Theme already set to requested value, skipping");
      return;
    }
    try {
      await k.setTheme(u);
    } catch (w) {
      console.error("Error setting theme:", w);
    }
  };
  return f.useEffect(() => {
    const u = k.subscribeToTheme(O);
    k.getTheme().then(O).catch((T) => {
      console.warn("Error getting theme from background script, using fallback:", T);
      const l = ae();
      try {
        const y = localStorage.getItem("themePreference") || "system", U = y === "system" ? l : y;
        s(y), g(U);
      } catch {
        s(
          "system"
          /* SYSTEM */
        ), g(l);
      }
      n(!1);
    });
    const w = window.matchMedia("(prefers-color-scheme: dark)"), c = (T) => {
      console.log("System theme change detected:", T.matches ? "dark" : "light"), r === "system" && (g(
        T.matches ? "dark" : "light"
        /* LIGHT */
      ), k.setTheme(
        "system"
        /* SYSTEM */
      ));
    };
    return w.addEventListener("change", c), () => {
      console.log("Cleaning up theme context event listeners"), w.removeEventListener("change", c), u();
    };
  }, [r]), /* @__PURE__ */ K.jsx(q.Provider, { value: {
    theme: e,
    themePreference: r,
    toggleTheme: D,
    setTheme: _,
    isLoading: o
  }, children: a });
};
export {
  he as A,
  Ee as T,
  fe as a,
  oe as b,
  ue as c,
  ge as d,
  le as e,
  F as g,
  de as s,
  ce as u,
  ee as v
};
