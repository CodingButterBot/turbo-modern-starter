/**
 * Standalone script to handle logout functionality
 * This is used in the options.html and sidepanel.html pages
 */

// Constants
const DIRECTUS_URL_KEY = 'directusUrl';
const DIRECTUS_ACCESS_TOKEN_KEY = 'directusAccessToken';
const DIRECTUS_REFRESH_TOKEN_KEY = 'directusRefreshToken';
const DIRECTUS_TOKEN_EXPIRATION_KEY = 'directusTokenExpiration';
// For backwards compatibility
const DIRECTUS_TOKEN_KEY = 'directusToken';

// Get storage area to use (sync or local)
function getStorageArea() {
  if (typeof chrome !== 'undefined' && chrome.storage) {
    return chrome.storage.sync || chrome.storage.local;
  }
  return null;
}

// Set multiple values in storage
async function setMultipleValues(values) {
  return new Promise((resolve) => {
    const storage = getStorageArea();
    if (storage) {
      storage.set(values, () => {
        resolve(true);
      });
    } else {
      // Development fallback - using localStorage
      Object.entries(values).forEach(([key, value]) => {
        if (value === null) {
          localStorage.removeItem(key);
        } else {
          localStorage.setItem(key, JSON.stringify(value));
        }
      });
      resolve(true);
    }
  });
}

// Set a value in storage
async function setStorageValue(key, value) {
  return new Promise((resolve) => {
    const storage = getStorageArea();
    if (storage) {
      storage.set({ [key]: value }, () => {
        resolve(value);
      });
    } else {
      // Development fallback - using localStorage
      if (value === null) {
        localStorage.removeItem(key);
      } else {
        localStorage.setItem(key, JSON.stringify(value));
      }
      resolve(value);
    }
  });
}

// Get a value from storage
async function getStorageValue(key) {
  return new Promise((resolve) => {
    const storage = getStorageArea();
    if (storage) {
      storage.get([key], (result) => {
        resolve(result[key] || null);
      });
    } else {
      // Development fallback - using localStorage
      try {
        const item = localStorage.getItem(key);
        resolve(item ? JSON.parse(item) : null);
      } catch (e) {
        resolve(null);
      }
    }
  });
}

// Get the stored Directus access token
async function getDirectusToken() {
  try {
    // Get both tokens for backward compatibility
    const storage = getStorageArea();
    if (storage) {
      return new Promise((resolve) => {
        storage.get([DIRECTUS_ACCESS_TOKEN_KEY, DIRECTUS_TOKEN_KEY], (result) => {
          // Return the new token if it exists, otherwise fall back to the old token key
          resolve(result[DIRECTUS_ACCESS_TOKEN_KEY] || result[DIRECTUS_TOKEN_KEY] || null);
        });
      });
    } else {
      // Development fallback - localStorage
      try {
        const accessToken = localStorage.getItem(DIRECTUS_ACCESS_TOKEN_KEY);
        if (accessToken) return JSON.parse(accessToken);
        
        const legacyToken = localStorage.getItem(DIRECTUS_TOKEN_KEY);
        return legacyToken ? JSON.parse(legacyToken) : null;
      } catch (e) {
        return null;
      }
    }
  } catch (error) {
    console.error('Error getting Directus token:', error);
    return null;
  }
}

// Validate if the current token is still valid
async function validateToken() {
  try {
    // First, check if we have an expiration time
    const expiration = await getStorageValue(DIRECTUS_TOKEN_EXPIRATION_KEY);
    
    // If no expiration found, check if we have a legacy token (which we can't validate by expiration)
    if (!expiration) {
      const token = await getDirectusToken();
      // If we have a token but no expiration, assume it's still valid (legacy behavior)
      return !!token;
    }
    
    // If we have an expiration time, check if it's in the future
    // We add a 30-second buffer to account for network latency
    const isValid = expiration > (Date.now() + 30000);
    
    return isValid;
  } catch (error) {
    console.error('Error validating token:', error);
    return false;
  }
}

// Clear all auth tokens (logout)
async function clearDirectusToken() {
  try {
    await setMultipleValues({
      [DIRECTUS_ACCESS_TOKEN_KEY]: null,
      [DIRECTUS_REFRESH_TOKEN_KEY]: null,
      [DIRECTUS_TOKEN_EXPIRATION_KEY]: null,
      [DIRECTUS_TOKEN_KEY]: null, // Clear legacy token too
      isLoggedIn: false
    });
    return true;
  } catch (error) {
    console.error('Error clearing Directus tokens:', error);
    return false;
  }
}

// Check if user is authenticated
async function isAuthenticated() {
  return await validateToken();
}

// For use in the global scope of HTML pages
window.directusHelpers = {
  clearDirectusToken,
  getStorageValue,
  setStorageValue,
  setMultipleValues,
  isAuthenticated,
  validateToken,
  getDirectusToken
};