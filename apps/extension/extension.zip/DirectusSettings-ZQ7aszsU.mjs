import { r as n, j as e } from "./vendor-DASaGGaw.mjs";
import { a as A, b as a, u as E, g as w } from "./index-BBeyQze-.mjs";
const D = ({ className: i = "" }) => {
  const { themePreference: s, setTheme: m, theme: g, isLoading: u } = A();
  n.useEffect(() => {
    console.log("ThemeSelector - Current state:", {
      themePreference: s,
      theme: g,
      isLoading: u,
      documentHasDarkClass: document.documentElement.classList.contains("dark"),
      documentClassList: Array.from(document.documentElement.classList)
    });
  }, [s, g, u]);
  const c = (d) => {
    console.log("Setting theme to:", d), m(d), setTimeout(() => {
      console.log("After theme change, document has dark class:", document.documentElement.classList.contains("dark")), console.log("Document classList:", Array.from(document.documentElement.classList));
    }, 100);
  };
  return /* @__PURE__ */ e.jsxs("div", { className: `w-full ${i}`, children: [
    /* @__PURE__ */ e.jsx("h3", { className: "mb-2 text-lg font-medium text-gray-800 dark:text-white", children: "Theme" }),
    /* @__PURE__ */ e.jsx("p", { className: "mb-3 text-sm text-gray-600 dark:text-gray-300", children: "Choose your preferred theme appearance" }),
    /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-2 sm:flex-row", children: [
      /* @__PURE__ */ e.jsx(
        "button",
        {
          onClick: () => c(a.LIGHT),
          className: `flex flex-1 items-center justify-center rounded-lg border p-3 transition ${s === a.LIGHT ? "border-blue-500 bg-blue-50 dark:border-blue-400 dark:bg-blue-900/30" : "border-gray-200 bg-white hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:hover:bg-gray-700"}`,
          children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col items-center", children: [
            /* @__PURE__ */ e.jsx("svg", { className: "mb-2 size-8 text-yellow-500", fill: "currentColor", viewBox: "0 0 20 20", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ e.jsx("path", { fillRule: "evenodd", d: "M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z", clipRule: "evenodd" }) }),
            /* @__PURE__ */ e.jsx("span", { className: `text-sm font-medium ${s === a.LIGHT ? "text-blue-700 dark:text-blue-400" : "text-gray-800 dark:text-gray-300"}`, children: "Light" })
          ] })
        }
      ),
      /* @__PURE__ */ e.jsx(
        "button",
        {
          onClick: () => c(a.DARK),
          className: `flex flex-1 items-center justify-center rounded-lg border p-3 transition ${s === a.DARK ? "border-blue-500 bg-blue-50 dark:border-blue-400 dark:bg-blue-900/30" : "border-gray-200 bg-white hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:hover:bg-gray-700"}`,
          children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col items-center", children: [
            /* @__PURE__ */ e.jsx("svg", { className: "mb-2 size-8 text-indigo-600 dark:text-indigo-400", fill: "currentColor", viewBox: "0 0 20 20", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ e.jsx("path", { d: "M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" }) }),
            /* @__PURE__ */ e.jsx("span", { className: `text-sm font-medium ${s === a.DARK ? "text-blue-700 dark:text-blue-400" : "text-gray-800 dark:text-gray-300"}`, children: "Dark" })
          ] })
        }
      ),
      /* @__PURE__ */ e.jsx(
        "button",
        {
          onClick: () => c(a.SYSTEM),
          className: `flex flex-1 items-center justify-center rounded-lg border p-3 transition ${s === a.SYSTEM ? "border-blue-500 bg-blue-50 dark:border-blue-400 dark:bg-blue-900/30" : "border-gray-200 bg-white hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:hover:bg-gray-700"}`,
          children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col items-center", children: [
            /* @__PURE__ */ e.jsx("svg", { className: "mb-2 size-8 text-gray-600 dark:text-gray-400", fill: "currentColor", viewBox: "0 0 20 20", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ e.jsx("path", { fillRule: "evenodd", d: "M3 5a2 2 0 012-2h10a2 2 0 012 2v8a2 2 0 01-2 2h-2.22l.123.489.804.804A1 1 0 0113 18H7a1 1 0 01-.707-1.707l.804-.804L7.22 15H5a2 2 0 01-2-2V5zm5.771 7H5V5h10v7H8.771z", clipRule: "evenodd" }) }),
            /* @__PURE__ */ e.jsx("span", { className: `text-sm font-medium ${s === a.SYSTEM ? "text-blue-700 dark:text-blue-400" : "text-gray-800 dark:text-gray-300"}`, children: "System" })
          ] })
        }
      )
    ] }),
    /* @__PURE__ */ e.jsxs("p", { className: "mt-2 text-xs text-gray-500 dark:text-gray-400", children: [
      s === a.LIGHT && "Using light theme for all extension pages",
      s === a.DARK && "Using dark theme for all extension pages",
      s === a.SYSTEM && "Following your system appearance settings"
    ] }),
    /* @__PURE__ */ e.jsxs("div", { className: "mt-4 rounded bg-gray-100 p-2 text-xs dark:bg-gray-700", children: [
      /* @__PURE__ */ e.jsx("p", { children: /* @__PURE__ */ e.jsx("strong", { children: "Debug Info:" }) }),
      /* @__PURE__ */ e.jsxs("p", { children: [
        "Preference: ",
        s
      ] }),
      /* @__PURE__ */ e.jsxs("p", { children: [
        "Active Theme: ",
        g
      ] }),
      /* @__PURE__ */ e.jsxs("p", { children: [
        "Loading: ",
        u ? "Yes" : "No"
      ] }),
      /* @__PURE__ */ e.jsxs("p", { children: [
        "Dark Class: ",
        document.documentElement.classList.contains("dark") ? "Yes" : "No"
      ] })
    ] })
  ] });
}, $ = () => {
  const { isAuthenticated: i, isLoading: s, checkAuth: m, login: g, logout: u, error: c } = E(), [d, N] = n.useState(""), [x, k] = n.useState(""), [M, f] = n.useState(""), [p, y] = n.useState(""), [j, z] = n.useState(""), [h, b] = n.useState(!1), [S, v] = n.useState(!0);
  n.useEffect(() => {
    const r = { current: !0 };
    return (async () => {
      if (r.current)
        try {
          if (v((t) => !t && r.current ? !0 : t), s || await m(), !r.current) return;
          if (i) {
            const t = await w();
            t && r.current && f((T) => T || t);
          }
          c && r.current && o(c, "error");
        } catch (t) {
          console.warn("Error loading Directus settings:", t), r.current && o("Could not load your settings. Please try again.", "error");
        } finally {
          r.current && v(!1);
        }
    })(), () => {
      r.current = !1;
    };
  }, [i, c, s, m]);
  const o = (r, l = "success") => {
    y(r), z(l), l === "success" && setTimeout(() => {
      y("");
    }, 5e3);
  }, C = async () => {
    if (!d || !x) {
      o("Please enter both email and password", "error");
      return;
    }
    try {
      if (b(!0), y(""), await g(d, x)) {
        const l = await w();
        l && f(l), o("Authentication successful", "success"), k("");
      } else
        o("Authentication failed", "error");
    } catch (r) {
      console.warn("Error authenticating with Directus:", r);
      let l = "Authentication failed";
      const t = r;
      t.message && t.message.includes("401") ? l = "Invalid credentials. Please check your email and password." : t.message && (t.message.includes("Failed to fetch") || t.message.includes("NetworkError")) && (l = "Could not connect to Directus server."), o(l, "error");
    } finally {
      b(!1);
    }
  }, L = async () => {
    try {
      b(!0), await u(), f(""), o("Successfully logged out", "success");
    } catch (r) {
      console.warn("Error logging out:", r), o("Error logging out", "error");
    } finally {
      b(!1);
    }
  };
  return S || s ? /* @__PURE__ */ e.jsx("div", { className: "flex min-h-32 items-center justify-center", children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col items-center", children: [
    /* @__PURE__ */ e.jsxs("svg", { className: "mb-4 size-8 animate-spin text-blue-500", xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", children: [
      /* @__PURE__ */ e.jsx("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }),
      /* @__PURE__ */ e.jsx("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" })
    ] }),
    /* @__PURE__ */ e.jsx("p", { className: "text-gray-600 dark:text-gray-300", children: "Loading settings..." })
  ] }) }) : /* @__PURE__ */ e.jsxs("div", { className: "rounded-lg bg-white p-5 shadow dark:bg-gray-800", children: [
    /* @__PURE__ */ e.jsx("h2", { className: "mb-6 text-xl font-bold text-gray-800 dark:text-white", children: "Directus Settings" }),
    p && /* @__PURE__ */ e.jsxs("div", { className: `mb-5 flex items-start rounded-lg border p-3 text-sm ${j === "success" ? "border-green-200 bg-green-50 text-green-800 dark:border-green-700 dark:bg-green-900/30 dark:text-green-400" : "border-red-200 bg-red-50 text-red-800 dark:border-red-700 dark:bg-red-900/30 dark:text-red-400"}`, children: [
      /* @__PURE__ */ e.jsx("svg", { className: "mr-2 size-5 shrink-0", fill: "currentColor", viewBox: "0 0 20 20", children: j === "success" ? /* @__PURE__ */ e.jsx("path", { fillRule: "evenodd", d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z", clipRule: "evenodd" }) : /* @__PURE__ */ e.jsx("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z", clipRule: "evenodd" }) }),
      /* @__PURE__ */ e.jsx("span", { children: p })
    ] }),
    /* @__PURE__ */ e.jsxs("div", { className: "mt-6 border-t border-gray-200 pt-6 dark:border-gray-700", children: [
      /* @__PURE__ */ e.jsx("h3", { className: "mb-4 text-lg font-medium text-gray-800 dark:text-white", children: "Authentication" }),
      i ? /* @__PURE__ */ e.jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ e.jsx("div", { className: "rounded-lg border border-green-200 bg-green-50 p-3 dark:border-green-700 dark:bg-green-900/30", children: /* @__PURE__ */ e.jsxs("div", { className: "flex items-center", children: [
          /* @__PURE__ */ e.jsx("svg", { className: "mr-2 size-5 text-green-700 dark:text-green-400", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ e.jsx("path", { fillRule: "evenodd", d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z", clipRule: "evenodd" }) }),
          /* @__PURE__ */ e.jsx("span", { className: "font-medium text-green-800 dark:text-green-400", children: "Successfully authenticated with Directus" })
        ] }) }),
        /* @__PURE__ */ e.jsx(
          "button",
          {
            className: "w-full rounded-md border border-gray-300 bg-gray-100 px-4 py-2 text-gray-800 transition hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 disabled:opacity-50 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600",
            onClick: L,
            disabled: h,
            children: h ? "Logging out..." : "Log out"
          }
        )
      ] }) : /* @__PURE__ */ e.jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ e.jsxs("div", { className: "mb-4", children: [
          /* @__PURE__ */ e.jsx("label", { className: "mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300", children: "Email" }),
          /* @__PURE__ */ e.jsx(
            "input",
            {
              type: "email",
              className: "w-full rounded-md border border-gray-300 p-2 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white",
              value: d,
              onChange: (r) => N(r.target.value),
              placeholder: "your.email@example.com"
            }
          )
        ] }),
        /* @__PURE__ */ e.jsxs("div", { className: "mb-4", children: [
          /* @__PURE__ */ e.jsx("label", { className: "mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300", children: "Password" }),
          /* @__PURE__ */ e.jsx(
            "input",
            {
              type: "password",
              className: "w-full rounded-md border border-gray-300 p-2 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white",
              value: x,
              onChange: (r) => k(r.target.value),
              placeholder: "••••••••"
            }
          )
        ] }),
        /* @__PURE__ */ e.jsx(
          "button",
          {
            className: "w-full rounded-md bg-blue-600 px-4 py-2 text-white transition hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 disabled:opacity-50",
            onClick: C,
            disabled: h || !d || !x,
            children: h ? /* @__PURE__ */ e.jsxs("span", { className: "flex items-center justify-center", children: [
              /* @__PURE__ */ e.jsxs("svg", { className: "-ml-1 mr-2 size-4 animate-spin text-white", xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", children: [
                /* @__PURE__ */ e.jsx("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }),
                /* @__PURE__ */ e.jsx("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" })
              ] }),
              "Authenticating..."
            ] }) : "Log in to Directus"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ e.jsx("div", { className: "mt-6 border-t border-gray-200 pt-6 dark:border-gray-700", children: /* @__PURE__ */ e.jsx(D, {}) })
  ] });
};
export {
  $ as D
};
