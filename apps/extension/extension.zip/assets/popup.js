import { j as e, r as p, c as y, R as w } from "../vendor-DASaGGaw.mjs";
import { D as f } from "../DirectusSettings-ZQ7aszsU.mjs";
import { M as j } from "../ModuleComponent-lkT_wqH8.mjs";
import { A as k, u as v, T as N } from "../index-BBeyQze-.mjs";
const C = () => {
  const [o, s] = p.useState("module"), { isAuthenticated: x, isLoading: h } = v(), m = () => {
    var r, i;
    (r = chrome == null ? void 0 : chrome.runtime) != null && r.openOptionsPage ? chrome.runtime.openOptionsPage() : window.open((i = chrome == null ? void 0 : chrome.runtime) != null && i.getURL ? chrome.runtime.getURL("options.html") : "options.html");
  }, u = () => {
    var r, i;
    try {
      (r = chrome == null ? void 0 : chrome.sidePanel) != null && r.open && ((i = chrome == null ? void 0 : chrome.tabs) != null && i.query) ? chrome.tabs.query({ active: !0, currentWindow: !0 }, async (n) => {
        try {
          if (n && n.length > 0 && n[0].id) {
            const t = n[0].id;
            console.log("Opening sidepanel with tabId:", t), await chrome.sidePanel.open({ tabId: t }), console.log("Side panel opened successfully with tabId"), window.close();
          } else {
            const t = await new Promise((a) => {
              var d;
              (d = chrome == null ? void 0 : chrome.windows) != null && d.getCurrent ? chrome.windows.getCurrent(a) : a(void 0);
            });
            if (t != null && t.id) {
              const a = t.id;
              console.log("Opening sidepanel with windowId:", a), await chrome.sidePanel.open({ windowId: a }), console.log("Side panel opened successfully with windowId"), window.close();
            } else
              console.error("Neither tab ID nor window ID available"), l();
          }
        } catch (t) {
          console.error("Failed to open side panel:", t), l();
        }
      }) : (console.warn("Side panel API not available, falling back to popup"), l());
    } catch (n) {
      console.error("Error in sidepanel opener:", n), l();
    }
  }, l = () => {
    var r;
    window.open(
      (r = chrome == null ? void 0 : chrome.runtime) != null && r.getURL ? chrome.runtime.getURL("sidepanel.html") : "sidepanel.html",
      "_blank",
      "width=400,height=600,resizable=yes"
    );
  }, g = () => /* @__PURE__ */ e.jsx("div", { className: "rounded-lg bg-white p-4 shadow dark:bg-gray-800", children: /* @__PURE__ */ e.jsxs("div", { className: "py-8 text-center", children: [
    /* @__PURE__ */ e.jsx("svg", { className: "mx-auto mb-6 size-16 text-blue-500", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ e.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" }) }),
    /* @__PURE__ */ e.jsx("h2", { className: "mb-3 text-xl font-bold text-gray-800 dark:text-white", children: "Authentication Required" }),
    /* @__PURE__ */ e.jsx("p", { className: "mx-auto mb-6 max-w-md text-gray-600 dark:text-gray-300", children: "You need to connect to Directus to use the module functionality. Please go to Settings to configure your connection." }),
    /* @__PURE__ */ e.jsx(
      "button",
      {
        onClick: () => s("settings"),
        className: "mx-2 rounded-md bg-blue-600 px-6 py-2 text-white transition hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50",
        children: "Go to Settings"
      }
    ),
    /* @__PURE__ */ e.jsx(
      "button",
      {
        onClick: () => s("about"),
        className: "mx-2 rounded-md bg-gray-200 px-6 py-2 text-gray-800 transition hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600",
        children: "Learn More"
      }
    )
  ] }) }), b = () => /* @__PURE__ */ e.jsxs("div", { className: "rounded-lg bg-white p-6 shadow dark:bg-gray-800", children: [
    /* @__PURE__ */ e.jsx("h2", { className: "mb-4 text-xl font-bold text-gray-800 dark:text-white", children: "About This Extension" }),
    /* @__PURE__ */ e.jsxs("div", { className: "prose dark:prose-invert", children: [
      /* @__PURE__ */ e.jsx("p", { className: "mb-4 text-gray-600 dark:text-gray-300", children: "This browser extension is built with the Turbo Modern Starter monorepo, showcasing modern web development practices in a unified workflow." }),
      /* @__PURE__ */ e.jsx("p", { className: "mb-4 text-gray-600 dark:text-gray-300", children: "It demonstrates integration with Directus CMS to power the module functionality, allowing you to:" }),
      /* @__PURE__ */ e.jsxs("ul", { className: "mb-4 list-disc pl-5 text-gray-600 dark:text-gray-300", children: [
        /* @__PURE__ */ e.jsx("li", { children: "Connect to a Directus instance" }),
        /* @__PURE__ */ e.jsx("li", { children: "Load module options from the CMS" }),
        /* @__PURE__ */ e.jsx("li", { children: "Interact with dynamic content" }),
        /* @__PURE__ */ e.jsx("li", { children: "Experience a seamless fallback to demo mode when offline" })
      ] }),
      /* @__PURE__ */ e.jsx("p", { className: "mt-6 border-t border-gray-200 pt-4 text-sm text-gray-500 dark:border-gray-700 dark:text-gray-400", children: "Version 0.0.1 | © 2025 Turbo Modern Starter" })
    ] })
  ] });
  return h && o === "module" ? /* @__PURE__ */ e.jsxs("div", { className: "min-h-[360px] w-full bg-gray-100 p-4 text-gray-800 transition-colors duration-150 dark:bg-gray-900 dark:text-gray-200", children: [
    /* @__PURE__ */ e.jsx("h1", { className: "mb-4 text-center text-xl font-bold", children: "Turbo Modern Starter" }),
    /* @__PURE__ */ e.jsx("div", { className: "rounded-lg border border-gray-200 bg-white p-5 shadow-lg dark:border-gray-700 dark:bg-gray-800", children: /* @__PURE__ */ e.jsx("div", { className: "flex min-h-32 items-center justify-center py-12", children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col items-center", children: [
      /* @__PURE__ */ e.jsxs("svg", { className: "mb-4 size-8 animate-spin text-blue-500", xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", children: [
        /* @__PURE__ */ e.jsx("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }),
        /* @__PURE__ */ e.jsx("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" })
      ] }),
      /* @__PURE__ */ e.jsx("p", { className: "text-gray-600 dark:text-gray-300", children: "Checking authentication status..." })
    ] }) }) })
  ] }) : /* @__PURE__ */ e.jsxs("div", { className: "min-h-[360px] w-full bg-gray-100 p-4 text-gray-800 transition-colors duration-150 dark:bg-gray-900 dark:text-gray-200", children: [
    /* @__PURE__ */ e.jsx("h1", { className: "mb-4 text-center text-xl font-bold", children: "Turbo Modern Starter" }),
    /* @__PURE__ */ e.jsxs("div", { className: "rounded-lg border border-gray-200 bg-white p-5 shadow-lg dark:border-gray-700 dark:bg-gray-800", children: [
      /* @__PURE__ */ e.jsxs("div", { className: "mb-4 flex border-b", children: [
        /* @__PURE__ */ e.jsx(
          "button",
          {
            className: `px-4 py-2 ${o === "module" ? "border-b-2 border-blue-500 font-medium text-blue-500" : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"}`,
            onClick: () => s("module"),
            children: "Module"
          }
        ),
        /* @__PURE__ */ e.jsx(
          "button",
          {
            className: `px-4 py-2 ${o === "settings" ? "border-b-2 border-blue-500 font-medium text-blue-500" : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"}`,
            onClick: () => s("settings"),
            children: "Settings"
          }
        ),
        /* @__PURE__ */ e.jsx(
          "button",
          {
            className: `px-4 py-2 ${o === "about" ? "border-b-2 border-blue-500 font-medium text-blue-500" : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"}`,
            onClick: () => s("about"),
            children: "About"
          }
        )
      ] }),
      /* @__PURE__ */ e.jsxs("div", { className: "mb-4 flex space-x-2", children: [
        /* @__PURE__ */ e.jsxs(
          "button",
          {
            onClick: m,
            className: "flex flex-1 items-center justify-center rounded-md bg-blue-600 px-3 py-2 text-sm text-white transition hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50",
            children: [
              /* @__PURE__ */ e.jsxs("svg", { className: "mr-1 size-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: [
                /* @__PURE__ */ e.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" }),
                /* @__PURE__ */ e.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z" })
              ] }),
              "Options"
            ]
          }
        ),
        /* @__PURE__ */ e.jsxs(
          "button",
          {
            onClick: u,
            className: "flex flex-1 items-center justify-center rounded-md bg-indigo-600 px-3 py-2 text-sm text-white transition hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50",
            children: [
              /* @__PURE__ */ e.jsx("svg", { className: "mr-1 size-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ e.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M4 6h16M4 12h16m-7 6h7" }) }),
              "Open Side Panel"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ e.jsxs("div", { className: "tab-content", children: [
        /* @__PURE__ */ e.jsx("div", { className: o === "module" ? "block" : "hidden", children: x ? /* @__PURE__ */ e.jsx(j, {}) : g() }, "module-tab"),
        /* @__PURE__ */ e.jsx("div", { className: o === "settings" ? "block" : "hidden", children: /* @__PURE__ */ e.jsx(f, {}) }, "settings-tab"),
        /* @__PURE__ */ e.jsx("div", { className: o === "about" ? "block" : "hidden", children: b() }, "about-tab")
      ] })
    ] })
  ] });
}, M = () => /* @__PURE__ */ e.jsx(k, { children: /* @__PURE__ */ e.jsx(C, {}) }), c = document.getElementById("root");
if (!c)
  throw new Error("Root element not found in the DOM");
y.createRoot(c).render(
  /* @__PURE__ */ e.jsx(w.StrictMode, { children: /* @__PURE__ */ e.jsx(N, { children: /* @__PURE__ */ e.jsx(M, {}) }) })
);
