import { c as o, j as e, R as n } from "../vendor-DASaGGaw.mjs";
import { A as s, M as a } from "../ModuleComponent-lkT_wqH8.mjs";
import { T as i, A as l } from "../index-BBeyQze-.mjs";
const d = () => /* @__PURE__ */ e.jsxs("div", { className: "flex min-h-screen w-full flex-col p-4 text-gray-800 dark:text-gray-200", children: [
  /* @__PURE__ */ e.jsx("h1", { className: "mb-4 text-xl font-bold", children: "Module Panel" }),
  /* @__PURE__ */ e.jsx("div", { className: "grow rounded-lg border border-gray-200 bg-white p-5 shadow-lg dark:border-gray-700 dark:bg-gray-800", children: /* @__PURE__ */ e.jsx(s, { fallback: /* @__PURE__ */ e.jsx("div", { className: "rounded-lg bg-white p-4 dark:bg-gray-800", children: /* @__PURE__ */ e.jsxs("div", { className: "py-6 text-center", children: [
    /* @__PURE__ */ e.jsx("svg", { className: "mx-auto mb-4 size-16 text-gray-400", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ e.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" }) }),
    /* @__PURE__ */ e.jsx("h2", { className: "mb-2 text-xl font-bold text-gray-800 dark:text-white", children: "Authentication Required" }),
    /* @__PURE__ */ e.jsx("p", { className: "mb-6 text-gray-600 dark:text-gray-300", children: "Your session has expired or you need to authenticate with Directus to access this content." }),
    /* @__PURE__ */ e.jsx(
      "button",
      {
        onClick: () => {
          var t;
          (t = chrome == null ? void 0 : chrome.runtime) != null && t.openOptionsPage ? chrome.runtime.openOptionsPage() : window.open("options.html", "_blank");
        },
        className: "rounded-md bg-blue-600 px-4 py-2 text-white transition hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50",
        children: "Go to Settings"
      }
    ),
    /* @__PURE__ */ e.jsx("p", { className: "mt-4 text-sm text-gray-500 dark:text-gray-400", children: "You'll be redirected to the options page to log in with your Directus credentials." })
  ] }) }), children: /* @__PURE__ */ e.jsx(a, {}) }) })
] }), r = document.getElementById("panel-root");
r ? o.createRoot(r).render(
  /* @__PURE__ */ e.jsx(n.StrictMode, { children: /* @__PURE__ */ e.jsx(i, { children: /* @__PURE__ */ e.jsx(l, { children: /* @__PURE__ */ e.jsx(d, {}) }) }) })
) : console.error('Side panel root element not found in the DOM - expected element with id "panel-root"');
