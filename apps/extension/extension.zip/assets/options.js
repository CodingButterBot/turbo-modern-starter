import { c as o, j as e, R as r } from "../vendor-DASaGGaw.mjs";
import { D as s } from "../DirectusSettings-ZQ7aszsU.mjs";
import { T as n, A as i } from "../index-BBeyQze-.mjs";
const m = () => /* @__PURE__ */ e.jsxs("div", { className: "mx-auto h-full max-w-md p-6", children: [
  /* @__PURE__ */ e.jsx("h1", { className: "mb-4 text-xl font-bold text-gray-800 dark:text-white", children: "Extension Options" }),
  /* @__PURE__ */ e.jsx(s, {})
] }), t = document.getElementById("options-root");
t ? o.createRoot(t).render(
  /* @__PURE__ */ e.jsx(r.StrictMode, { children: /* @__PURE__ */ e.jsx(n, { children: /* @__PURE__ */ e.jsx(i, { children: /* @__PURE__ */ e.jsx(m, {}) }) }) })
) : console.error('Options root element not found in the DOM - expected element with id "options-root"');
