// Check for user's theme preference
const darkModePreference = localStorage.getItem('themePreference');

// Apply dark mode if:
// 1. User explicitly set dark mode, or
// 2. User prefers system setting and system is dark
if (
  darkModePreference === 'dark' || 
  (darkModePreference === 'system' && 
   window.matchMedia('(prefers-color-scheme: dark)').matches)
) {
  document.documentElement.classList.add('dark');
} else {
  document.documentElement.classList.remove('dark');
}

console.log('Initial theme applied:', {
  storedPreference: darkModePreference,
  isDark: document.documentElement.classList.contains('dark')
});