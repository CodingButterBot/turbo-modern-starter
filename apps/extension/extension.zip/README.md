# Extension Public Assets

This directory contains public assets for the browser extension, such as icons and other static files.

You'll need to add the following icon files here:
- icon-16.png (16x16)
- icon-48.png (48x48)
- icon-128.png (128x128)