import { r as t, j as e } from "./vendor-DASaGGaw.mjs";
import { u as C, d as z, v as M, c as O, e as j, s as T } from "./index-BBeyQze-.mjs";
const D = ({ children: x, fallback: w }) => {
  const { isAuthenticated: i, isLoading: r } = C(), [n, g] = t.useState(r), [m, h] = t.useState(i && !r), [p, c] = t.useState(!i && !r);
  t.useEffect(() => {
    let l = null, s = null, d = null;
    return r ? (g(!0), s = window.setTimeout(() => h(!1), 50), d = window.setTimeout(() => c(!1), 50)) : (l = window.setTimeout(() => g(!1), 100), i ? (h(!0), d = window.setTimeout(() => c(!1), 50)) : (c(!0), s = window.setTimeout(() => h(!1), 50))), () => {
      l && window.clearTimeout(l), s && window.clearTimeout(s), d && window.clearTimeout(d);
    };
  }, [i, r]);
  const f = () => {
    var l, s;
    (l = chrome == null ? void 0 : chrome.runtime) != null && l.openOptionsPage ? chrome.runtime.openOptionsPage() : window.open((s = chrome == null ? void 0 : chrome.runtime) != null && s.getURL ? chrome.runtime.getURL("options.html") : "options.html");
  }, b = t.useMemo(() => /* @__PURE__ */ e.jsx("div", { className: "rounded-lg bg-white p-4 shadow dark:bg-gray-800", children: /* @__PURE__ */ e.jsxs("div", { className: "py-6 text-center", children: [
    /* @__PURE__ */ e.jsx("svg", { className: "mx-auto mb-4 size-16 text-gray-400", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ e.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" }) }),
    /* @__PURE__ */ e.jsx("h2", { className: "mb-2 text-xl font-bold text-gray-800 dark:text-white", children: "Authentication Required" }),
    /* @__PURE__ */ e.jsx("p", { className: "mb-6 text-gray-600 dark:text-gray-300", children: "Your session has expired or you need to authenticate with Directus to access this content." }),
    /* @__PURE__ */ e.jsx(
      "button",
      {
        onClick: f,
        className: "rounded-md bg-blue-600 px-4 py-2 text-white transition hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50",
        children: "Go to Settings"
      }
    ),
    /* @__PURE__ */ e.jsx("p", { className: "mt-4 text-sm text-gray-500 dark:text-gray-400", children: "You'll be redirected to the options page to log in with your Directus credentials." })
  ] }) }), []);
  return /* @__PURE__ */ e.jsxs("div", { className: "relative w-full", children: [
    n && /* @__PURE__ */ e.jsxs("div", { className: "absolute inset-0 z-10 p-4 text-center", children: [
      /* @__PURE__ */ e.jsx("div", { className: "mx-auto mb-4 size-8 animate-spin rounded-full border-4 border-blue-500 border-t-transparent" }),
      /* @__PURE__ */ e.jsx("p", { className: "text-gray-600 dark:text-gray-300", children: "Checking authentication..." })
    ] }),
    /* @__PURE__ */ e.jsx("div", { className: `${m ? "opacity-100" : "opacity-0 pointer-events-none absolute inset-0"} transition-opacity duration-200`, children: x }),
    /* @__PURE__ */ e.jsx("div", { className: `${p ? "opacity-100" : "opacity-0 pointer-events-none absolute inset-0"} transition-opacity duration-200`, children: w || b })
  ] });
}, I = () => {
  const [x, w] = t.useState([]), [i, r] = t.useState([]), [n, g] = t.useState(null), [m, h] = t.useState(null), [p, c] = t.useState(!1), [f, b] = t.useState(!1), [l, s] = t.useState(null), [d, y] = t.useState(!1);
  t.useEffect(() => {
    z(), (async () => {
      try {
        c(!0), s(null);
        const a = await M();
        console.log("Module component token validation result:", { isTokenValid: a });
        const u = await O({
          filter: { status: { _eq: "published" } }
        });
        u.length === 1 && String(u[0].id) === "1" && u[0].name === "Demo Options (Not Authenticated)" ? (console.log("Demo mode detected from module options data"), y(!0)) : (console.log("Using authenticated data mode"), y(!1)), w(u);
      } catch (a) {
        console.error("Error fetching module options:", a), s("We couldn't load your module options. Please try again later.");
      } finally {
        c(!1);
      }
    })();
  }, []), t.useEffect(() => {
    if (!n) {
      r([]);
      return;
    }
    (async () => {
      try {
        c(!0), s(null), h(null);
        const a = await j(n);
        r(a);
      } catch (a) {
        if (console.error("Error fetching module option items:", a), d && n === 1)
          try {
            const u = await j(1);
            r(u);
            return;
          } catch (u) {
            console.error("Failed to fetch demo items as fallback:", u);
          }
        s("Could not load items for this option. Please try another selection.");
      } finally {
        c(!1);
      }
    })();
  }, [n, d]);
  const v = (o) => {
    const a = parseInt(o.target.value, 10);
    g(isNaN(a) ? null : a);
  }, N = async () => {
    if (!(!n || !i.length))
      try {
        b(!0), s(null);
        const o = await T(i, n);
        h(o);
      } catch (o) {
        console.error("Error spinning wheel:", o), s("There was a problem spinning the wheel. Please try again.");
      } finally {
        b(!1);
      }
  }, k = () => d ? /* @__PURE__ */ e.jsx("div", { className: "mb-4 rounded-lg border border-blue-200 bg-blue-100 p-3 text-sm text-blue-700", children: /* @__PURE__ */ e.jsxs("div", { className: "flex items-start", children: [
    /* @__PURE__ */ e.jsx("svg", { className: "mr-2 mt-0.5 size-4 shrink-0", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ e.jsx("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z", clipRule: "evenodd" }) }),
    /* @__PURE__ */ e.jsxs("div", { children: [
      /* @__PURE__ */ e.jsx("p", { className: "font-medium", children: "Demo Mode Active" }),
      /* @__PURE__ */ e.jsxs("p", { className: "mt-1", children: [
        "You're using sample data. ",
        /* @__PURE__ */ e.jsx("button", { onClick: () => window.location.href = "options.html", className: "font-medium underline", children: "Log in" }),
        " to access your Directus data."
      ] })
    ] })
  ] }) }) : null, S = () => /* @__PURE__ */ e.jsxs("div", { className: "rounded-lg bg-white p-4 shadow dark:bg-gray-800", children: [
    /* @__PURE__ */ e.jsx("h2", { className: "mb-4 text-lg font-bold dark:text-white", children: "Module Demo" }),
    /* @__PURE__ */ e.jsx(k, {}),
    l && /* @__PURE__ */ e.jsxs("div", { className: "mb-4 flex items-start rounded-lg border border-red-200 bg-red-100 p-3 text-sm text-red-700", children: [
      /* @__PURE__ */ e.jsx("svg", { className: "mr-2 mt-0.5 size-4 shrink-0", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ e.jsx("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z", clipRule: "evenodd" }) }),
      /* @__PURE__ */ e.jsx("span", { children: l })
    ] }),
    /* @__PURE__ */ e.jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ e.jsx("label", { className: "mb-2 block text-sm font-medium dark:text-gray-300", children: "Select Options:" }),
      /* @__PURE__ */ e.jsxs(
        "select",
        {
          className: "w-full rounded-md border border-gray-300 p-2 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white",
          value: n || "",
          onChange: v,
          disabled: p || x.length === 0,
          children: [
            /* @__PURE__ */ e.jsx("option", { value: "", children: "-- Select Options --" }),
            x.map((o) => /* @__PURE__ */ e.jsx("option", { value: o.id, children: o.name }, o.id))
          ]
        }
      )
    ] }),
    /* @__PURE__ */ e.jsx(
      "button",
      {
        className: "w-full rounded-md bg-blue-600 px-4 py-2 text-white transition hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 disabled:cursor-not-allowed disabled:opacity-50",
        onClick: N,
        disabled: f || !n || i.length === 0,
        children: f ? /* @__PURE__ */ e.jsxs("span", { className: "flex items-center justify-center", children: [
          /* @__PURE__ */ e.jsxs("svg", { className: "-ml-1 mr-2 size-4 animate-spin text-white", xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", children: [
            /* @__PURE__ */ e.jsx("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }),
            /* @__PURE__ */ e.jsx("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" })
          ] }),
          "Spinning..."
        ] }) : "Spin the Wheel"
      }
    ),
    m && /* @__PURE__ */ e.jsxs("div", { className: "mt-4 rounded-lg border border-dashed border-gray-300 bg-gray-50 p-4 text-center dark:border-gray-600 dark:bg-gray-700", children: [
      /* @__PURE__ */ e.jsx("h3", { className: "mb-2 font-medium text-gray-700 dark:text-gray-200", children: "Result:" }),
      /* @__PURE__ */ e.jsx("p", { className: "text-xl font-bold text-gray-900 dark:text-white", children: m.label }),
      m.color && /* @__PURE__ */ e.jsx(
        "div",
        {
          className: "mx-auto mt-3 size-6 rounded-full shadow-inner",
          style: { backgroundColor: m.color }
        }
      )
    ] }),
    p && /* @__PURE__ */ e.jsxs("div", { className: "mt-4 flex items-center justify-center", children: [
      /* @__PURE__ */ e.jsxs("svg", { className: "mr-2 size-5 animate-spin text-blue-500", xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", children: [
        /* @__PURE__ */ e.jsx("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }),
        /* @__PURE__ */ e.jsx("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" })
      ] }),
      /* @__PURE__ */ e.jsx("span", { className: "text-sm text-gray-500 dark:text-gray-400", children: "Loading..." })
    ] })
  ] });
  return /* @__PURE__ */ e.jsx(D, { children: /* @__PURE__ */ e.jsx(S, {}) });
};
export {
  D as A,
  I as M
};
