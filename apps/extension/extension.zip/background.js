/**
 * Background script for the Turbo Modern Starter extension
 * This script runs in the background and provides functionality for the extension.
 */

// Set up side panel
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('Extension installed:', details.reason);
  
  // Set up side panel configuration at installation time
  if (chrome.sidePanel) {
    try {
      await chrome.sidePanel.setOptions({
        path: 'sidepanel.html',
        enabled: true
      });
      console.log('Side panel configured successfully');
    } catch (error) {
      console.error('Error configuring side panel:', error);
    }
  }
  
  // Initialize any other required setup here
  if (details.reason === 'install') {
    console.log('First installation');
    // Add first-time setup logic here
  } else if (details.reason === 'update') {
    console.log('Extension updated from version', details.previousVersion);
    // Add update logic here
  }
});

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Message received in background script:', message);
  
  // Handle different message types
  if (message.type === 'GET_DATA') {
    // Example: send back some data
    sendResponse({ success: true, data: { timestamp: Date.now() } });
  } else if (message.type === 'OPEN_SIDEPANEL') {
    // Handle sidepanel opening request using the correct approach
    try {
      // In Chrome 114+, we need to open the sidepanel for the current tab
      if (chrome.sidePanel) {
        // Get the current active tab first
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
          if (tabs && tabs.length > 0) {
            const tabId = tabs[0].id;
            
            // Open sidepanel for the specific tab
            chrome.sidePanel.open({tabId})
              .then(() => {
                console.log(`Side panel opened successfully for tab ${tabId}`);
                sendResponse({ success: true });
              })
              .catch(error => {
                console.error('Error opening side panel:', error);
                sendResponse({ 
                  success: false, 
                  error: 'Could not open side panel: ' + (error.message || 'Unknown error')
                });
              });
          } else {
            sendResponse({ 
              success: false, 
              error: 'No active tab found to open side panel' 
            });
          }
        });
      } else {
        console.error('Side panel API not available');
        sendResponse({ 
          success: false, 
          error: 'Side panel API not available in this browser'
        });
      }
    } catch (error) {
      console.error('Error opening sidepanel:', error);
      sendResponse({ success: false, error: error.message });
    }
    return true; // Indicate we'll send a response asynchronously
  }
  
  // Return true to indicate an asynchronous response is coming
  return true;
});