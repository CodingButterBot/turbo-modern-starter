// Service worker for the Chrome extension
// Proper lifecycle management for Chrome extension service worker
chrome.runtime.onInstalled.addListener((details) => {
  console.log('Extension installed or updated:', details.reason);
  
  // Initialize any extension state on first install
  if (details.reason === 'install') {
    // Set default settings in storage
    chrome.storage.local.set({
      darkMode: false,
      notifications: true,
      autoRefresh: false,
      debugging: false,
      syncFrequency: false,
      isLoggedIn: false
    }, () => {
      console.log('Default settings initialized');
    });
  }

  // Initialize side panel when extension is installed
  if (chrome.sidePanel) {
    chrome.sidePanel.setOptions({
      path: 'sidepanel.html',
      enabled: true
    });
  }
});

// Handle suspension (service worker being terminated)
chrome.runtime.onSuspend.addListener(() => {
  console.log('Extension is being suspended');
  // Clean up any pending operations
});

// Listen for messages from extension pages
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Received message:', message);
  
  if (message.action === 'openSidePanel') {
    try {
      if (chrome.sidePanel) {
        // Get the active tab to use its ID for opening the side panel
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs && tabs.length > 0) {
            // Open side panel with tabId parameter
            chrome.sidePanel.open({ tabId: tabs[0].id });
            console.log('Side panel opened for tab:', tabs[0].id);
            sendResponse({ success: true });
          } else {
            // Fallback to try with current window
            chrome.windows.getCurrent((window) => {
              chrome.sidePanel.open({ windowId: window.id });
              console.log('Side panel opened for window:', window.id);
              sendResponse({ success: true });
            });
          }
        });
      } else {
        console.error('Side panel API not available');
        sendResponse({ success: false, error: 'Side panel API not available' });
      }
    } catch (error) {
      console.error('Error opening side panel:', error);
      sendResponse({ success: false, error: error.message });
    }
    
    // Must return true for async response
    return true;
  }
  
  // Other message handlers could go here
});