/**
 * Background script for the Turbo Modern Starter extension
 * This script acts as a central state manager and service worker for the extension.
 * It uses the official Directus SDK for authentication and API operations.
 */

// Import the Directus SDK bridge for background script
importScripts('src/lib/directus-sdk-background.js');

// Storage keys constants
const STORAGE_KEYS = {
  URL: 'directus_url',
  ACCESS_TOKEN: 'directusAccessToken',
  REFRESH_TOKEN: 'directusRefreshToken',
  EXPIRATION: 'directusTokenExpiration',
  AUTH_STATE: 'directus_auth_state'
};

// Default Directus URL
const DEFAULT_DIRECTUS_URL = 'http://localhost:8055';

// State for the extension
const extensionState = {
  auth: {
    isAuthenticated: false,
    isLoading: false,
    error: null
  },
  theme: {
    theme: 'light',
    themePreference: 'system',
    isLoading: false
  }
};

// Message types
const MESSAGE_TYPES = {
  // Auth messages
  AUTH_STATUS_CHECK: 'AUTH_STATUS_CHECK',
  AUTH_LOGIN: 'AUTH_LOGIN',
  AUTH_LOGOUT: 'AUTH_LOGOUT',
  AUTH_REFRESH_TOKEN: 'AUTH_REFRESH_TOKEN',
  AUTH_STATUS_CHANGED: 'AUTH_STATUS_CHANGED',
  AUTH_DEBUG: 'AUTH_DEBUG',
  
  // Theme messages
  THEME_GET: 'THEME_GET',
  THEME_SET: 'THEME_SET',
  THEME_TOGGLE: 'THEME_TOGGLE',
  THEME_CHANGED: 'THEME_CHANGED',
  
  // General messages
  EXTENSION_STATE_REQUEST: 'EXTENSION_STATE_REQUEST',
  EXTENSION_STATE_BROADCAST: 'EXTENSION_STATE_BROADCAST',
  
  // UI messages
  OPEN_SIDEPANEL: 'OPEN_SIDEPANEL'
};

// Wait for Directus SDK to initialize (it self-initializes, see directus-sdk-background.js)
// Create the Directus client instance
let directusClient = new self.DirectusBackgroundClient({
  url: DEFAULT_DIRECTUS_URL
});

// Authentication Debug Helper Function
async function logAuthState() {
  try {
    const authData = await new Promise(resolve => {
      chrome.storage.local.get([
        'isAuthenticated', 
        'directusAccessToken', 
        'directusRefreshToken',
        'directusTokenExpiration'
      ], resolve);
    });
    
    console.log('Authentication State:', {
      isAuthenticatedFlag: !!authData.isAuthenticated,
      hasAccessToken: !!authData.directusAccessToken,
      hasRefreshToken: !!authData.directusRefreshToken,
      tokenExpiration: authData.directusTokenExpiration ? new Date(authData.directusTokenExpiration).toISOString() : null,
      currentTime: new Date().toISOString(),
      isExpired: authData.directusTokenExpiration ? Date.now() > authData.directusTokenExpiration : null,
      inExtensionState: extensionState.auth.isAuthenticated
    });
    
    // Get token validation result
    const isValid = await directusClient.validateToken();
    console.log('Token validation result:', { isValid });
  } catch (error) {
    console.error('Error logging auth state:', error);
  }
}

// Initialize state from storage
async function initializeState() {
  try {
    // Get auth data from client
    const authState = await directusClient.getAuthState();
    extensionState.auth.isAuthenticated = authState.isAuthenticated;
    
    // Get theme data
    const themeData = await new Promise(resolve => {
      chrome.storage.local.get([
        'themePreference',
        'darkMode'
      ], resolve);
    });
    
    // Update theme state
    if (themeData.themePreference) {
      extensionState.theme.themePreference = themeData.themePreference;
      extensionState.theme.theme = themeData.darkMode ? 'dark' : 'light';
    }
    
    // Log detailed authentication state
    await logAuthState();
    
    console.log('Extension state initialized:', extensionState);
  } catch (error) {
    console.error('Error initializing extension state:', error);
  }
}

// Detect system theme preference
function detectSystemTheme() {
  // Can't use window.matchMedia in a service worker, so we'll use storage
  // or default to light theme
  return 'light';
}

// Update theme based on preference
function updateTheme(preference) {
  if (preference === 'system') {
    extensionState.theme.theme = detectSystemTheme();
  } else {
    extensionState.theme.theme = preference;
  }
  
  extensionState.theme.themePreference = preference;
  
  // Save to storage
  chrome.storage.local.set({
    themePreference: preference,
    darkMode: extensionState.theme.theme === 'dark'
  });
  
  // Broadcast theme change
  broadcastThemeChange();
}

// Toggle theme (cycle through light, dark, system)
function toggleTheme() {
  const current = extensionState.theme.themePreference;
  
  if (current === 'light') {
    updateTheme('dark');
  } else if (current === 'dark') {
    updateTheme('system');
  } else {
    updateTheme('light');
  }
  
  return extensionState.theme;
}

// Broadcast theme change to all contexts
function broadcastThemeChange() {
  try {
    chrome.runtime.sendMessage({
      type: MESSAGE_TYPES.THEME_CHANGED,
      payload: { ...extensionState.theme }
    }).catch(error => {
      // Silently ignore "Receiving end does not exist" errors
      console.debug('Theme broadcast error (expected):', error);
    });
  } catch (error) {
    // Silently ignore runtime errors
    console.debug('Theme broadcast runtime error (expected):', error);
  }
}

// Broadcast auth state change to all contexts
function broadcastAuthChange() {
  try {
    chrome.runtime.sendMessage({
      type: MESSAGE_TYPES.AUTH_STATUS_CHANGED,
      payload: { ...extensionState.auth }
    }).catch(error => {
      // Silently ignore "Receiving end does not exist" errors
      console.debug('Auth broadcast error (expected):', error);
    });
  } catch (error) {
    // Silently ignore runtime errors
    console.debug('Auth broadcast runtime error (expected):', error);
  }
}

// Broadcast entire state to all contexts
function broadcastState() {
  try {
    chrome.runtime.sendMessage({
      type: MESSAGE_TYPES.EXTENSION_STATE_BROADCAST,
      payload: {
        auth: { ...extensionState.auth },
        theme: { ...extensionState.theme }
      }
    }).catch(error => {
      // Silently ignore "Receiving end does not exist" errors
      console.debug('State broadcast error (expected):', error);
    });
  } catch (error) {
    // Silently ignore runtime errors
    console.debug('State broadcast runtime error (expected):', error);
  }
}

// Track token refresh attempts
const tokenRefreshTracker = {
  lastAttempt: 0,
  attemptCount: 0,
  backoffPeriod: 45000, // 45 seconds
  maxAttempts: 2, // Reduce max attempts
  resetTimer: null,
  isRefreshing: false // Track if refresh is in progress
};

// Handle auth login
async function handleLogin(credentials) {
  try {
    // Update state to show loading
    extensionState.auth.isLoading = true;
    broadcastAuthChange();
    
    // Attempt to authenticate with Directus API
    const { email, password } = credentials;
    if (!email || !password) {
      throw new Error('Email and password are required');
    }
    
    console.log('Attempting to authenticate with Directus...', { email });
    
    // Authenticate with Directus
    const authResult = await directusClient.authenticateWithCredentials({ email, password });
    console.log('Authentication successful, token received', { 
      hasAccessToken: !!authResult.accessToken,
      hasRefreshToken: !!authResult.refreshToken,
      expiresIn: authResult.expiresIn,
    });
    
    // After successful authentication, update the extension state
    extensionState.auth.isAuthenticated = true;
    extensionState.auth.isLoading = false;
    extensionState.auth.error = null;
    
    // Also update our local storage flag for backward compatibility
    await new Promise(resolve => {
      chrome.storage.local.set({
        isAuthenticated: true
      }, resolve);
    });
    
    // Log detailed authentication state after login
    await logAuthState();
    
    // Broadcast the auth change
    broadcastAuthChange();
    
    return extensionState.auth;
  } catch (error) {
    console.error('Login error:', error);
    
    // Update state to show error
    extensionState.auth.isAuthenticated = false;
    extensionState.auth.isLoading = false;
    extensionState.auth.error = error instanceof Error ? error.message : 'Login failed';
    
    // Broadcast the auth change
    broadcastAuthChange();
    
    return extensionState.auth;
  }
}

// Handle auth logout
async function handleLogout() {
  try {
    // Update state to show loading
    extensionState.auth.isLoading = true;
    broadcastAuthChange();
    
    // Clear tokens
    await directusClient.clearAuthTokens();
    
    // Also update our local storage flag for backward compatibility
    await new Promise(resolve => {
      chrome.storage.local.set({
        isAuthenticated: false
      }, resolve);
    });
    
    // Update state
    extensionState.auth.isAuthenticated = false;
    extensionState.auth.isLoading = false;
    extensionState.auth.error = null;
    
    // Broadcast changes
    broadcastAuthChange();
    
    return extensionState.auth;
  } catch (error) {
    console.error('Logout error:', error);
    
    extensionState.auth.isLoading = false;
    extensionState.auth.error = error instanceof Error ? error.message : 'Logout failed';
    
    broadcastAuthChange();
    
    return extensionState.auth;
  }
}

// Handle auth token refresh
async function handleTokenRefresh() {
  try {
    // Prevent concurrent refresh attempts
    if (tokenRefreshTracker.isRefreshing) {
      console.warn('Token refresh already in progress, skipping duplicate request');
      return extensionState.auth;
    }
    
    const now = Date.now();
    
    // Check if we're in a backoff period due to too many recent attempts
    if (tokenRefreshTracker.attemptCount >= tokenRefreshTracker.maxAttempts && 
        now - tokenRefreshTracker.lastAttempt < tokenRefreshTracker.backoffPeriod) {
      console.warn(`Token refresh throttled: ${tokenRefreshTracker.attemptCount} attempts in the last ${Math.round((now - tokenRefreshTracker.lastAttempt) / 1000)}s`);
      
      // Don't show loading state when we're throttled
      extensionState.auth.isLoading = false;
      extensionState.auth.error = 'Token refresh temporarily disabled due to too many attempts';
      broadcastAuthChange();
      
      return extensionState.auth;
    }
    
    // Set refreshing flag
    tokenRefreshTracker.isRefreshing = true;
    
    try {
      // Update state to show loading
      extensionState.auth.isLoading = true;
      broadcastAuthChange();
      
      // Update tracker
      tokenRefreshTracker.lastAttempt = now;
      tokenRefreshTracker.attemptCount++;
      
      // Set a timeout to reset the counter after the backoff period
      if (tokenRefreshTracker.resetTimer) {
        clearTimeout(tokenRefreshTracker.resetTimer);
      }
      tokenRefreshTracker.resetTimer = setTimeout(() => {
        console.log('Resetting token refresh attempt counter');
        tokenRefreshTracker.attemptCount = 0;
      }, tokenRefreshTracker.backoffPeriod);
      
      // Attempt to refresh the token
      const refreshSuccessful = await directusClient.refreshToken();
      console.log('Token refresh result:', refreshSuccessful);
      
      // Update state based on refresh result
      if (refreshSuccessful) {
        // Reset attempt counter on success
        tokenRefreshTracker.attemptCount = 0;
        
        extensionState.auth.isAuthenticated = true;
        extensionState.auth.isLoading = false;
        extensionState.auth.error = null;
        
        // Also update our local storage flag for backward compatibility
        await new Promise(resolve => {
          chrome.storage.local.set({
            isAuthenticated: true
          }, resolve);
        });
      } else {
        // If refresh failed, we need to clear the auth state
        extensionState.auth.isAuthenticated = false;
        extensionState.auth.isLoading = false;
        extensionState.auth.error = 'Token refresh failed';
        
        // Update local storage
        await new Promise(resolve => {
          chrome.storage.local.set({
            isAuthenticated: false
          }, resolve);
        });
      }
      
      // Broadcast changes
      broadcastAuthChange();
      
      return extensionState.auth;
    } finally {
      // Always reset the refreshing flag when done
      tokenRefreshTracker.isRefreshing = false;
    }
  } catch (error) {
    console.error('Token refresh error:', error);
    
    // Reset refreshing flag on error
    tokenRefreshTracker.isRefreshing = false;
    
    // Update state to show error
    extensionState.auth.isLoading = false;
    extensionState.auth.error = error instanceof Error ? error.message : 'Token refresh failed';
    
    // Broadcast changes
    broadcastAuthChange();
    
    return extensionState.auth;
  }
}

// Handle side panel setup
function setupSidePanel() {
  if (chrome.sidePanel) {
    chrome.sidePanel.setOptions({
      path: 'sidepanel.html',
      enabled: true
    })
    .then(() => console.log('Side panel configured successfully'))
    .catch(error => console.error('Error configuring side panel:', error));
  }
}

// Set up the extension
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('Extension installed:', details.reason);
  
  // Initialize state
  await initializeState();
  
  // Set up side panel configuration at installation time
  setupSidePanel();
  
  // Initialize any other required setup here
  if (details.reason === 'install') {
    console.log('First installation');
    // Add first-time setup logic here
  } else if (details.reason === 'update') {
    console.log('Extension updated from version', details.previousVersion);
    // Add update logic here
  }
});

// Listen for messages from contexts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Message received in background script:', message);
  
  // Handle different message types
  switch (message.type) {
    // Auth messages
    case MESSAGE_TYPES.AUTH_STATUS_CHECK:
      // Just return the current state - no async operation
      sendResponse(extensionState.auth);
      return false; // Synchronous response
      
    case MESSAGE_TYPES.AUTH_DEBUG:
      // Return detailed auth debug info
      (async () => {
        try {
          // Log to console
          await logAuthState();
          
          // Get token validation status
          let isTokenValid = await directusClient.validateToken();
          
          // Get stored token info
          const tokenData = await new Promise(resolve => {
            chrome.storage.local.get([
              'directusAccessToken', 
              'directusRefreshToken',
              'directusTokenExpiration'
            ], resolve);
          });
          
          // Build response with detailed debug info
          const debugInfo = {
            extensionAuthState: { ...extensionState.auth },
            hasAccessToken: !!tokenData.directusAccessToken,
            hasRefreshToken: !!tokenData.directusRefreshToken,
            tokenExpiration: tokenData.directusTokenExpiration ? new Date(tokenData.directusTokenExpiration).toISOString() : null,
            currentTime: new Date().toISOString(),
            isExpired: tokenData.directusTokenExpiration ? Date.now() > tokenData.directusTokenExpiration : null,
            tokenValidationResult: isTokenValid,
            tokenPreview: tokenData.directusAccessToken ? 
              `${tokenData.directusAccessToken.substring(0, 10)}...${tokenData.directusAccessToken.substring(tokenData.directusAccessToken.length - 5)}` : 
              null
          };
          
          sendResponse({ success: true, debugInfo });
        } catch (error) {
          console.error('Error in auth debug:', error);
          sendResponse({ 
            success: false, 
            error: error instanceof Error ? error.message : 'Unknown error' 
          });
        }
      })();
      return true; // Async response
      
    case MESSAGE_TYPES.AUTH_LOGIN:
      (async () => {
        try {
          const result = await handleLogin(message.payload);
          sendResponse(result);
        } catch (error) {
          console.error('Error in login:', error);
          sendResponse({
            isAuthenticated: false,
            isLoading: false,
            error: error instanceof Error ? error.message : 'Login failed'
          });
        }
      })();
      return true; // Async response
      
    case MESSAGE_TYPES.AUTH_LOGOUT:
      (async () => {
        try {
          const result = await handleLogout();
          sendResponse(result);
        } catch (error) {
          console.error('Error in logout:', error);
          sendResponse({
            isAuthenticated: false,
            isLoading: false,
            error: error instanceof Error ? error.message : 'Logout failed'
          });
        }
      })();
      return true; // Async response
      
    case MESSAGE_TYPES.AUTH_REFRESH_TOKEN:
      (async () => {
        try {
          const result = await handleTokenRefresh();
          sendResponse(result);
        } catch (error) {
          console.error('Error in token refresh:', error);
          sendResponse({
            isAuthenticated: false,
            isLoading: false,
            error: error instanceof Error ? error.message : 'Token refresh failed'
          });
        }
      })();
      return true; // Async response
      
    // Theme messages
    case MESSAGE_TYPES.THEME_GET:
      try {
        sendResponse(extensionState.theme);
      } catch (error) {
        console.error('Error in THEME_GET response:', error);
      }
      return false; // Synchronous response
      
    case MESSAGE_TYPES.THEME_SET:
      try {
        if (message.payload && message.payload.themePreference) {
          updateTheme(message.payload.themePreference);
        }
        sendResponse(extensionState.theme);
      } catch (error) {
        console.error('Error in THEME_SET:', error);
        sendResponse(extensionState.theme); // Return current state anyway
      }
      return false; // Synchronous response
      
    case MESSAGE_TYPES.THEME_TOGGLE:
      try {
        toggleTheme();
        sendResponse(extensionState.theme);
      } catch (error) {
        console.error('Error in THEME_TOGGLE:', error);
        sendResponse(extensionState.theme); // Return current state anyway
      }
      return false; // Synchronous response
      
    // General messages
    case MESSAGE_TYPES.EXTENSION_STATE_REQUEST:
      try {
        sendResponse({
          auth: { ...extensionState.auth },
          theme: { ...extensionState.theme }
        });
      } catch (error) {
        console.error('Error in EXTENSION_STATE_REQUEST:', error);
        // Provide a fallback response
        sendResponse({
          auth: { isAuthenticated: false, isLoading: false, error: null },
          theme: { theme: 'light', themePreference: 'system', isLoading: false }
        });
      }
      return false; // Synchronous response
      
    case MESSAGE_TYPES.OPEN_SIDEPANEL:
      (async () => {
        try {
          if (chrome.sidePanel) {
            // Ensure side panel is properly set up
            await chrome.sidePanel.setOptions({
              path: 'sidepanel.html',
              enabled: true
            });
            
            // First attempt: Just provide tabId, as this is usually sufficient
            const tabs = await new Promise(resolve => {
              chrome.tabs.query({ active: true, currentWindow: true }, resolve);
            });

            if (tabs && tabs.length > 0) {
              try {
                const tabId = tabs[0].id;
                console.log('Opening sidepanel with tabId:', tabId);
                
                // Use only tabId parameter
                await chrome.sidePanel.open({ tabId });
                
                sendResponse({
                  success: true,
                  method: 'tab_id',
                  sidePanelAvailable: true
                });
                return;
              } catch (error) {
                console.warn('Could not open sidepanel with tabId only:', error);
                // Continue with fallbacks
              }
            }
            
            // Second attempt: Just use current window
            try {
              const currentWindow = await new Promise(resolve => {
                chrome.windows.getCurrent(resolve);
              });
              
              if (currentWindow) {
                const windowId = currentWindow.id;
                console.log('Opening sidepanel with windowId:', windowId);
                
                // Use only windowId parameter
                await chrome.sidePanel.open({ windowId });
                
                sendResponse({
                  success: true,
                  method: 'window_id',
                  sidePanelAvailable: true
                });
                return;
              }
            } catch (error) {
              console.warn('Could not open sidepanel with windowId:', error);
              // Fall through to final fallback
            }
            
            // Final fallback: Open as a popup window
            console.log('Falling back to popup window for sidepanel');
            chrome.windows.create({
              url: 'sidepanel.html',
              type: 'popup',
              width: 400,
              height: 600
            });
            
            sendResponse({
              success: true,
              method: 'popup_fallback',
              sidePanelAvailable: false
            });
          } else {
            // Side panel API not available, open as a popup window
            console.log('Side panel API not available, opening as popup');
            chrome.windows.create({
              url: 'sidepanel.html',
              type: 'popup',
              width: 400,
              height: 600
            });
            
            sendResponse({ 
              success: true,
              method: 'popup_only',
              sidePanelAvailable: false
            });
          }
        } catch (error) {
          console.error('Error handling sidepanel request:', error);
          
          // Fallback to popup as last resort
          try {
            chrome.windows.create({
              url: 'sidepanel.html',
              type: 'popup',
              width: 400,
              height: 600
            });
            
            sendResponse({
              success: true,
              method: 'popup_after_error',
              sidePanelAvailable: false,
              error: error instanceof Error ? error.message : 'Unknown error'
            });
          } catch (finalError) {
            sendResponse({ 
              success: false, 
              error: error instanceof Error ? error.message : 'Unknown error',
              sidePanelAvailable: false
            });
          }
        }
      })();
      return true; // Async response
      
    default:
      // Unknown message type - synchronous response
      sendResponse({ error: 'Unknown message type' });
      return false;
  }
});

// Listen for storage changes
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local') {
    let authChanged = false;
    let themeChanged = false;
    
    // Check for auth changes
    if (changes.isAuthenticated || 
        changes.directusAccessToken || 
        changes.directusRefreshToken || 
        changes.directusTokenExpiration) {
      
      if (changes.isAuthenticated) {
        extensionState.auth.isAuthenticated = changes.isAuthenticated.newValue;
      }
      
      authChanged = true;
    }
    
    // Check for theme changes
    if (changes.themePreference || changes.darkMode) {
      if (changes.themePreference) {
        extensionState.theme.themePreference = changes.themePreference.newValue;
      }
      
      if (changes.darkMode) {
        extensionState.theme.theme = changes.darkMode.newValue ? 'dark' : 'light';
      }
      
      themeChanged = true;
    }
    
    // Broadcast changes
    if (authChanged) {
      broadcastAuthChange();
    }
    
    if (themeChanged) {
      broadcastThemeChange();
    }
    
    if (authChanged || themeChanged) {
      broadcastState();
    }
  }
});