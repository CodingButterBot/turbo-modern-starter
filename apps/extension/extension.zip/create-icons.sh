#\!/bin/bash
for size in 16 48 128; do
  convert -size ${size}x${size} xc:navy -fill white -gravity center -font Helvetica -pointsize $((size/3)) -annotate 0 "TMS" "icon-${size}.png"
  echo "Created icon-${size}.png"
done
